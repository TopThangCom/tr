java -jar getLatinTag.jar cs  "obchod" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "melodie" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "výlet" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "kancelář" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "přijmout" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "řádek" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "v ústech" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "přesný" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "symbol" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "zemřít" 1000  keyword_cs.txt

java -jar getLatinTag.jar cs  "tichý" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "kámen" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "maličký" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "stoupání" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "v pohodě" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "Design" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "špatná" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "hodně" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "experimentu" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "spodní" 1000  keyword_cs.txt

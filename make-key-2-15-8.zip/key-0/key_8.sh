java -jar getLatinTag.jar cs  "chvíle" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "stupnice" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "hlasitý" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "na jaře" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "pozorovat" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "dítě" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "rovný" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "souhláska" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "národ" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "slovník" 1000  keyword_cs.txt

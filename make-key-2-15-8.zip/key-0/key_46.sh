java -jar getLatinTag.jar cs  "vítr" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "otázka" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "stát se" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "kompletní" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "loď" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "plocha" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "polovina" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "skála" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "objednávka" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "oheň" 1000  keyword_cs.txt

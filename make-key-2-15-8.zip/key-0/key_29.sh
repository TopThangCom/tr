java -jar getLatinTag.jar cs  "region" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "velikost" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "se liší" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "usadit" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "mluvit" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "hmotnost" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "obecně" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "led" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "záležitost" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "kruh" 1000  keyword_cs.txt

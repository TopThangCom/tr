java -jar getLatinTag.jar cs  "tmavá" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "stroj" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "poznámka" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "počkejte" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "plán" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "obrázek" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "hvězda" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "box" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "podstatné jméno" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "pole" 1000  keyword_cs.txt

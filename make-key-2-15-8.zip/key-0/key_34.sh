java -jar getLatinTag.jar cs  "skok" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "dítě" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "osm" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "obec" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "Seznamte se" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "kořen" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "koupit" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "zvýšit" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "řešit" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "kov" 1000  keyword_cs.txt

java -jar getLatinTag.jar cs  "místo" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "slyšet" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "nejlepší" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "hodina" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "lepší" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "skutečný" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "během" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "sto" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "pět" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "pamatovat si" 1000  keyword_cs.txt

java -jar getLatinTag.jar cs  "mezi" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "jednotka" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "síla" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "město" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "v pořádku" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "jisté" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "podívejte se" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "spadnout" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "vést" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "křik" 1000  keyword_cs.txt

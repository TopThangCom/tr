java -jar getLatinTag.jar cs  "sloužit" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "se objeví" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "silnice" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "mapa" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "déšť" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "pravidlo" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "vládnout" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "vytáhněte" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "zima" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "oznámení" 1000  keyword_cs.txt

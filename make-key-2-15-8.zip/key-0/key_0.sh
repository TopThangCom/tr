java -jar getLatinTag.jar cs  "na jih" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "problém" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "kus" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "řekl" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "věděl," 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "pas" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "od" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "horní" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "celý" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "král" 1000  keyword_cs.txt

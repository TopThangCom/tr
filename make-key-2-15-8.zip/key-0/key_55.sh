java -jar getLatinTag.jar cs  "kontinent" 1000  keyword_cs.txt

java -jar getLatinTag.jar cs  "pozdě" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "běh" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "ne" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "zatímco" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "stiskněte tlačítko" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "close" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "noc" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "skutečný" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "život" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "málo" 1000  keyword_cs.txt

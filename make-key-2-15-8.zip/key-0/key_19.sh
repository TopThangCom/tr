java -jar getLatinTag.jar cs  "růst" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "studie" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "stále" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "učit se" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "rostlina" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "kryt" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "jídlo" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "slunce" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "čtyři" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "mezi" 1000  keyword_cs.txt

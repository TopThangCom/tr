java -jar getLatinTag.jar cs  "záznam" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "loď" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "společné" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "zlato" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "možné" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "letadlo" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "Místo toho" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "suché" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "Zajímalo by mě," 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "smích" 1000  keyword_cs.txt

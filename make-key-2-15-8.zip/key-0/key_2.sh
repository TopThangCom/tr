java -jar getLatinTag.jar cs  "nejméně" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "problémy" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "křičet" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "mimo" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "napsal" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "semínko" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "tón" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "připojit se" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "naznačují," 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "čistý" 1000  keyword_cs.txt

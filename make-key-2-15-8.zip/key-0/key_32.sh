java -jar getLatinTag.jar cs  "měsíc" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "milionů" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "nést" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "úprava" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "šťastný" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "doufám, že" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "květina" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "oblékli" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "podivný" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "pryč" 1000  keyword_cs.txt

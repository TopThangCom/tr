java -jar getLatinTag.jar cs  "elektrické" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "očekávat" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "kost" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "zábradlí" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "představte si" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "poskytovat" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "souhlasí s tím," 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "tedy" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "jemný" 1000  keyword_cs.txt
java -jar getLatinTag.jar cs  "žena" 1000  keyword_cs.txt

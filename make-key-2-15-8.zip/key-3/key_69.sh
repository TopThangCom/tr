java -jar getLatinTag.jar ro  "posibil" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "avion" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "locul" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "uscat" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "întreb" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "râs" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "mie" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "în urmă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "a fugit" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "verifica" 1000  keyword_ro.txt

java -jar getLatinTag.jar ro  "pește" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "munte" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "opri" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "dată" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "de bază" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "auzi" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cal" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cut" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "sigur" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "ceas" 1000  keyword_ro.txt

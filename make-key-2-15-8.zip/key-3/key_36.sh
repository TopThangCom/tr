java -jar getLatinTag.jar ro  "arde" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "deal" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "în condiții de siguranță" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "pisică" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "secol" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "ia în considerare" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "tipul" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "lege" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "bit" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "coasta" 1000  keyword_ro.txt

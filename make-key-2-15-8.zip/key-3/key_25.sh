java -jar getLatinTag.jar ro  "liber" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "minut" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "puternic" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "special" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "minte" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "în spatele" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "clar" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "coadă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "produc" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "fapt" 1000  keyword_ro.txt

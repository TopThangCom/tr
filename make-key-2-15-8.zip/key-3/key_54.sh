java -jar getLatinTag.jar ro  "indica" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "Radio" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "a vorbit" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "atomul" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "uman" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "istorie" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "efect" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "electric" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "os" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "feroviar" 1000  keyword_ro.txt

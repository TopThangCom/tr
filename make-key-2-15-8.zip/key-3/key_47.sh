java -jar getLatinTag.jar ro  "dificil" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "medicul" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "vă rog" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "proteja" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "amiază" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cultură" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "modernă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "element" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "lovit" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "elev" 1000  keyword_ro.txt

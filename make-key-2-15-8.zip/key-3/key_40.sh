java -jar getLatinTag.jar ro  "sufix" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "mai ales" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "fig" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "speriat" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "uriaș" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "sora" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "oțel" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "discuta" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "similare" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "ghid" 1000  keyword_ro.txt

java -jar getLatinTag.jar ro  "patru" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "între" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "de stat" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "păstra" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "ochi" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "niciodată" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "trecut" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "lăsa" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "gând" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "oraș" 1000  keyword_ro.txt

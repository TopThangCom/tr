java -jar getLatinTag.jar ro  "începe" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "am" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "de mers pe jos" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "exemplu" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "ușura" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "hârtie" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "grup" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "întotdeauna" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "muzica" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "aceste" 1000  keyword_ro.txt

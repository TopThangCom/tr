java -jar getLatinTag.jar ro  "cu excepția" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "semințe" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "ton" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "se alăture" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "sugerează" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "curat" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "pauză" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "doamnă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "curte" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "rău" 1000  keyword_ro.txt

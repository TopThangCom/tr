java -jar getLatinTag.jar ro  "valoare" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "lupta" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "minciună" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "bate" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "excita" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "natural" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "vedere" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "sens" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "de capital" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "nu va" 1000  keyword_ro.txt

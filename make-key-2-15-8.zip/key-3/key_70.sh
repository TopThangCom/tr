java -jar getLatinTag.jar ro  "colț" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "partid" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "aprovizionare" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "a cărui" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "localiza" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "inel" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "caracter" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "insectă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "prins" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "perioada" 1000  keyword_ro.txt

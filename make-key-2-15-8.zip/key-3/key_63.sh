java -jar getLatinTag.jar ro  "lovitură" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "ulei" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "sânge" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "atingeți" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "a crescut" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "sută" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "amesteca" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "echipa" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "sârmă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "costul" 1000  keyword_ro.txt

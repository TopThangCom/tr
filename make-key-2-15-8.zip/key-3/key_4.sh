java -jar getLatinTag.jar ro  "târziu" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "a alerga" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "nu face" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "în timp ce" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "presă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "aproape" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "noapte" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "reală" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "viață" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "puțini" 1000  keyword_ro.txt

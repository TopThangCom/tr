java -jar getLatinTag.jar ro  "toate" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "acolo" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "când" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "în sus" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "utilizare" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "dumneavoastră" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cale" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "despre" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "multe" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "apoi" 1000  keyword_ro.txt

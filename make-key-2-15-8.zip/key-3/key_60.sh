java -jar getLatinTag.jar ro  "nord" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "carte" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "efectueze" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "a luat" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "știință" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "mânca" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cameră" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "prieten" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "început" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "idee" 1000  keyword_ro.txt

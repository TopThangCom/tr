java -jar getLatinTag.jar ro  "alunecare" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "victorie" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "vis" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "seară" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "condiție" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "hrana pentru animale" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "instrument" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "totală" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "miros" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "vale" 1000  keyword_ro.txt

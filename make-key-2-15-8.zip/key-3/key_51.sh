java -jar getLatinTag.jar ro  "uita-te" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "mai mult" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "zi" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "ar putea" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "merge" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "vin" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "număr" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "sunet" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cel mai" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "oameni" 1000  keyword_ro.txt

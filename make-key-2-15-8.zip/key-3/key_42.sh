java -jar getLatinTag.jar ro  "spațiu" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "a auzit" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cel mai bun" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "oră" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "mai bine" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "adevărat" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "în timpul" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "sute de" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cinci" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "amintiți-vă" 1000  keyword_ro.txt

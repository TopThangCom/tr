java -jar getLatinTag.jar ro  "copac" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cruce" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "fermă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "greu" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "Start" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "s-ar putea" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "poveste" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "ferăstrău" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "trage" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "stânga" 1000  keyword_ro.txt

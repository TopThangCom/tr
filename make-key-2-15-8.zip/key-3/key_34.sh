java -jar getLatinTag.jar ro  "masă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "călătorie" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "mai puțin" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "dimineață" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "zece" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "mai mulți" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "vocală" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "spre" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "război" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "împotriva" 1000  keyword_ro.txt

java -jar getLatinTag.jar ro  "experiență" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "scor" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "măr" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cumpărat" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "a condus" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "Pitch" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "strat" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "masa" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "band" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "frânghie" 1000  keyword_ro.txt

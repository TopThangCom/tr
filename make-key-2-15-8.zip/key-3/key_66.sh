java -jar getLatinTag.jar ro  "cutelor" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "gaură" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "salt" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "opt" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "întâlni" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "rădăcină" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cumpăra" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "ridica" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "de metal" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "apăsare" 1000  keyword_ro.txt

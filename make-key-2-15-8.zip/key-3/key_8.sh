java -jar getLatinTag.jar ro  "colecta" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "salva" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "de control" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "zecimal" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "ureche" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "altceva" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "destul de" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "rupt" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "caz" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "de mijloc" 1000  keyword_ro.txt

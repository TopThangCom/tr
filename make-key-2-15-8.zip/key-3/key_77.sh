java -jar getLatinTag.jar ro  "atât" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "marcă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "de multe ori" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "scrisoare" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "până la" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "milă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "râu" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "masina" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "picioare" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "îngrijire" 1000  keyword_ro.txt

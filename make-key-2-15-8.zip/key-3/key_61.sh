java -jar getLatinTag.jar ro  "a spus" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "Știam" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "trece" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "întrucât" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "top" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "întreg" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "rege" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "stradă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "inci" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "multiplica" 1000  keyword_ro.txt

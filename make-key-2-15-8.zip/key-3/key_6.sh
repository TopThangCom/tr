java -jar getLatinTag.jar ro  "experimentul" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "de jos" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cheie" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "fier" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "singur" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "băț" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "plat" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "douăzeci" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "piele" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "zâmbet" 1000  keyword_ro.txt

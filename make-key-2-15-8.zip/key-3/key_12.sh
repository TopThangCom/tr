java -jar getLatinTag.jar ro  "al doilea" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "suficient" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "simplu" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "fată" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "de obicei" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "tineri" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "gata" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "de mai sus" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "vreodată" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "roșu" 1000  keyword_ro.txt

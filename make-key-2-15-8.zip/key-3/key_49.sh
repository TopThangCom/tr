java -jar getLatinTag.jar ro  "față" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "săptămână" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "finală" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "a dat" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "verde" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "oh" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "rapid" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "dezvolta" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "oceanului" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cald" 1000  keyword_ro.txt

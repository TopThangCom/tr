java -jar getLatinTag.jar ro  "triunghi" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "planetă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "grabă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "șef" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "colonie" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "a mea" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cravată" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "intra" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "majoră" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "proaspăt" 1000  keyword_ro.txt

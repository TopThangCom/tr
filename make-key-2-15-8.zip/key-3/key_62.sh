java -jar getLatinTag.jar ro  "meu" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "peste" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cunoaște" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "de apă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "decât" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "apel" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "primul" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "putea" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "jos" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "lateral" 1000  keyword_ro.txt

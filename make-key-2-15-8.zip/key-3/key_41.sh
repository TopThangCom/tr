java -jar getLatinTag.jar ro  "fost" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "acum" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "găsi" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cap" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "stand" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "propriu" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "pagina" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "ar trebui" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "țară" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "găsite" 1000  keyword_ro.txt

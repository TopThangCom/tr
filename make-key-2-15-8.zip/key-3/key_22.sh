java -jar getLatinTag.jar ro  "plumb" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "strigăt" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "întuneric" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "mașină" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "notă" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "aștepta" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "planul de" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "figura" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "stele" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "cutie" 1000  keyword_ro.txt

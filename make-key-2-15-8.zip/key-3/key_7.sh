java -jar getLatinTag.jar ro  "șapte" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "punctul" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "a treia" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "trebuie" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "ținută" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "păr" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "descrie" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "bucătar" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "etaj" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "rezultat" 1000  keyword_ro.txt

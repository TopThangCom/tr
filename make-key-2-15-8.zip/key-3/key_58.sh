java -jar getLatinTag.jar ro  "pui" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "draga" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "inamic" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "raspunde" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "băutură" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "avea loc" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "suport" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "discurs" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "natura" 1000  keyword_ro.txt
java -jar getLatinTag.jar ro  "gama" 1000  keyword_ro.txt

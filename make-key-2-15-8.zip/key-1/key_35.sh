java -jar getLatinTag.jar az  "hər hansı bir" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "yeni" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "iş" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "hissə" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "almaq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "yer" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "etdi" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "yaşamaq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "harada" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "sonra" 1000  keyword_az.txt

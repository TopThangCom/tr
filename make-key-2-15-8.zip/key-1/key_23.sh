java -jar getLatinTag.jar az  "qulaq asmaq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "altı" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "masa" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "səyahət" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "səhər" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "sadə" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "sait" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "müharibə" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "lay" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "qarşı" 1000  keyword_az.txt

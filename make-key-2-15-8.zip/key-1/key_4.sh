java -jar getLatinTag.jar az  "elm" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "yemək" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "otaq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "dost" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "başladı" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "balıq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "dağ" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "dayandırmaq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "bir dəfə" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "baza" 1000  keyword_az.txt

java -jar getLatinTag.jar az  "camp" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "icad" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "pambıq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "anadan" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "quart" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "doqquz" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "yük maşını" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "səviyyəsi" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "şans" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "shop" 1000  keyword_az.txt

java -jar getLatinTag.jar az  "oturmaq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "irqi" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "pəncərə" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "mağaza" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "yay" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "qatar" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "yuxu" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "sübut etmək" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "tək" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "exercise" 1000  keyword_az.txt

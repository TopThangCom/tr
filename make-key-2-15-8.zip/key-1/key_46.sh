java -jar getLatinTag.jar az  "qonşu" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "yuma" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "bat" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "izdiham" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "qarğıdalı" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "müqayisə etmək" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "şer" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "string" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "zəng" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "asılı" 1000  keyword_az.txt

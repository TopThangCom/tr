java -jar getLatinTag.jar az  "mənim" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "üzərində" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "öyrənmək" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "su" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "zəng edin" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "ilk" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "kim" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "may" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "side" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "olmuşdur" 1000  keyword_az.txt

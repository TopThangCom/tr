java -jar getLatinTag.jar az  "polad" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "müzakirə etmək" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "irəli" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "oxşar" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "alma" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "alıb" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "rəhbərlik" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "meydança" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "coat" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "kütləvi" 1000  keyword_az.txt

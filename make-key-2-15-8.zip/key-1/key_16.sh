java -jar getLatinTag.jar az  "isə" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "mətbuat" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "gecə" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "real" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "həyat" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "bir neçə" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "şimal" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "kitab" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "keçirmək" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "aldı" 1000  keyword_az.txt

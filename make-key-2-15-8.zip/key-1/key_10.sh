java -jar getLatinTag.jar az  "tərk etmək" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "mahnı" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "ölçmək" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "qapı" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "məhsul" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "qara" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "qısa" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "say" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "sinif" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "külək" 1000  keyword_az.txt

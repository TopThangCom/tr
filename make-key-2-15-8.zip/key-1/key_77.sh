java -jar getLatinTag.jar az  "baxmayaraq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "hiss etmək" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "danışmaq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "quş" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "tezliklə" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "bədən" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "dog" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "ailə" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "birbaşa" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "yaradır" 1000  keyword_az.txt

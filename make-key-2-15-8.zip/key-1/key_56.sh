java -jar getLatinTag.jar az  "hazırlamaq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "duz" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "burun" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "cəm" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "hirs" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "iddia" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "qitə" 1000  keyword_az.txt

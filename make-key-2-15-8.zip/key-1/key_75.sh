java -jar getLatinTag.jar az  "daha" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "gün" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "bilər" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "getmək" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "gəlmək" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "sayı" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "səs" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "heç bir" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "ən" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "xalq" 1000  keyword_az.txt

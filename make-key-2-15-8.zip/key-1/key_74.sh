java -jar getLatinTag.jar az  "ikinci" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "kifayət qədər" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "düz" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "girl" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "adi" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "gənc" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "hazır" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "bax" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "qırmızı" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "siyahısı" 1000  keyword_az.txt

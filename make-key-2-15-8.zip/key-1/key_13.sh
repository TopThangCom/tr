java -jar getLatinTag.jar az  "parça" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "bilirdi" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "ildən" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "üst" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "kral" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "küçə" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "inch" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "çoxaltmaq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "heç bir şey" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "Əlbəttə" 1000  keyword_az.txt

java -jar getLatinTag.jar az  "çıxmaq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "hadisə" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "müqavilə" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "swim" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "müddət" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "arvad" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "ayaqqabı" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "çiyin" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "yaymaq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "təşkil etmək" 1000  keyword_az.txt

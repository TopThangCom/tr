java -jar getLatinTag.jar az  "download" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "düşdü" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "uyğun" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "axını" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "ədalətli" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "bank" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "toplamaq" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "yadda saxla" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "nəzarət" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "decimal" 1000  keyword_az.txt

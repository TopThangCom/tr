java -jar getLatinTag.jar az  "atom" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "insan" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "tarix" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "təsiri" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "elektrik" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "gözləyirik" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "sümük" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "rail" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "təsəvvür etmək" 1000  keyword_az.txt
java -jar getLatinTag.jar az  "təmin" 1000  keyword_az.txt

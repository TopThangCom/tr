java -jar getLatinTag.jar sq  "fruta" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i pasur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i trashë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ushtar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "procesi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "operoj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "praktikë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të ndara" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i vështirë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mjeku" 1000  keyword_sq.txt

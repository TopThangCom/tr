java -jar getLatinTag.jar sq  "mbushur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "lindje" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "bojë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "gjuha" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "në mesin e" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "njësi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fuqia" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "gjobë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "sigurt" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fluturojnë" 1000  keyword_sq.txt

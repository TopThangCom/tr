java -jar getLatinTag.jar sq  "i ngadalshëm" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "qendër" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "dashuri" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "person" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "paratë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shërbejnë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "Harta" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "rregull" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "qeverisur" 1000  keyword_sq.txt

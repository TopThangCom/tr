java -jar getLatinTag.jar sq  "largohen" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "song" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të matur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "dyer" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "produkt" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "e zezë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i shkurtër" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "numëror" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "klasë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "era" 1000  keyword_sq.txt

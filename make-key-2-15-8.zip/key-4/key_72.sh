java -jar getLatinTag.jar sq  "bashkohen" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "sugjerojnë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i pastër" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pushim" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "lady" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "oborr" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ngrihem" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "keq" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "goditje" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "naftës" 1000  keyword_sq.txt

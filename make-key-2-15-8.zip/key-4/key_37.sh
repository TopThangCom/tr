java -jar getLatinTag.jar sq  "udhëhequr" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "katran" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pallto" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "në masë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kartë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "band" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "litar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shqip" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fitore" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ëndërr" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "ato" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të dy" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mark" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shpesh" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "deri" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "milje" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "lumi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "makinë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "këmbët" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kujdes" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "ju lutem" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mbrojtur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mesditë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kulture" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "moderne" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "element" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "hit" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "studenti" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "qoshe" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "parti" 1000  keyword_sq.txt

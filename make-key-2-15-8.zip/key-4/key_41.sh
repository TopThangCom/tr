java -jar getLatinTag.jar sq  "më pak" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mëngjes" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "dhjetë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "thjeshtë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "zanore" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "drejt" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "luftë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "vë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kundër" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "model" 1000  keyword_sq.txt

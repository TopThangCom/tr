java -jar getLatinTag.jar sq  "ndonëse" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të ndjehen të" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "flasim" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "zog" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shpejt" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "trupi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "qen" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "familja" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "drejtpërdrejtë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "paraqesin" 1000  keyword_sq.txt

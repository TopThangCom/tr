java -jar getLatinTag.jar sq  "të gjithë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "atje" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "up" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "përdorimi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "tuaj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mënyrë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pastaj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shkruaj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kështu" 1000  keyword_sq.txt

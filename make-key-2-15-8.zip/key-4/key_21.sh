java -jar getLatinTag.jar sq  "bien" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të çojë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "qaj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "errët" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shënim" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pres" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "Plani" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shifër" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "yll" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kuti" 1000  keyword_sq.txt

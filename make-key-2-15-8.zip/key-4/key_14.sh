java -jar getLatinTag.jar sq  "dinte" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kaloj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "që prej" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "top" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "tërë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mbreti" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "rrugë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "inç" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shumohen" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "asgjë" 1000  keyword_sq.txt

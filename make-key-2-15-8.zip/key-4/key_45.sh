java -jar getLatinTag.jar sq  "të jetë e mundur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "aeroplan" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "Në vend" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "thatë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pyes veten" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "qesh" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mijë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "më parë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "vrapoi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kontrolloj" 1000  keyword_sq.txt

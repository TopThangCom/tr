java -jar getLatinTag.jar sq  "dëgjuar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "orë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "më mirë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "e vërtetë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "njëqind" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pesë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kujtoj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "hapi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fillim" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mbajë" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "emër" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fushë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "saktë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "gjendje" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kile" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "e bërë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "bukuri" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "qëndroi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "përmbaj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mësojnë" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "gjerë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "përgatisë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kripë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "hundë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shumës" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "zemërimi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pretendim" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kontinenti" 1000  keyword_sq.txt

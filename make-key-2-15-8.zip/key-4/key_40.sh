java -jar getLatinTag.jar sq  "ende" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mësoj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "bimë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mbuluar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ushqim" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "dielli" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "katër" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "në mes të" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shtet" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mbaj" 1000  keyword_sq.txt

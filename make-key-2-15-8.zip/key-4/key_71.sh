java -jar getLatinTag.jar sq  "jam" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pranishëm" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "rëndë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "valle" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "motor" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pozita" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "krah" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të gjerë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "lundrojnë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "material" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "finish" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të lumtur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shpresoj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "lule" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "vesh" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "çuditshme" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shkuar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "tregtisë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "melodi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "zyrë" 1000  keyword_sq.txt

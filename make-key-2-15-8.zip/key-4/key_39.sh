java -jar getLatinTag.jar sq  "bllok" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "tabelë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "hat" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shes" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "suksesi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "Kompania" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "zbres" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ngjarje" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i veçantë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "marrëveshje" 1000  keyword_sq.txt

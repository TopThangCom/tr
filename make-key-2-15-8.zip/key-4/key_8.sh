java -jar getLatinTag.jar sq  "paguajnë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mosha" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "seksion" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "veshje" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "cloud" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "surprizë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i qetë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "guri" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ngjit" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i ftohtë" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "i butë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "grua" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kapiten" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "guess" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "nevojshme" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mprehtë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "krahut" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "krijuar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fqinji" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "laj" 1000  keyword_sq.txt

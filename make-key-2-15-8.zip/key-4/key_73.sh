java -jar getLatinTag.jar sq  "i dytë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mjaft" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "plain" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "vajzë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "zakonshme" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i ri" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "gati" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "sipër" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i kuq" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "lista" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "moon" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ishull" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "këmbë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "sistemi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i zënë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "provë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "rekord" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "varkë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "përbashkët" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ari" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "heshtur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i gjatë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "rërë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "tokës" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "roll" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "temperatura" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "gisht" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "industri" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "Vlera" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "lufta" 1000  keyword_sq.txt

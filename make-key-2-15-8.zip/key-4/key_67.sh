java -jar getLatinTag.jar sq  "minutë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fortë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të veçantë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mendja" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "prapa" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "qartë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "bisht" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "prodhojnë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fakti" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "hapësirë" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "do të thoshte" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "herës" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "dhëmbët" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shell" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "qafë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "oksigjen" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "sheqer" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "vdekja" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "aftësi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "gratë" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "furnizim" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të cilit" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "unazë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "karakter" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "insekteve" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "periudha" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "tregojnë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "radio" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "foli" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "atom" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "nën" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "Emri" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shumë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "me anë të" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "formë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fjali" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mendoj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të ndihmojë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ulët" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "linjë" 1000  keyword_sq.txt

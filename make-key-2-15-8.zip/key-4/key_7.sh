java -jar getLatinTag.jar sq  "gënjeshtër" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "rrah" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "nxeh" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "natyrore" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "view" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kuptim" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kapitalit" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "nuk do të" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "karrige" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "rrezik" 1000  keyword_sq.txt

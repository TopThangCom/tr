java -jar getLatinTag.jar sq  "këto" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "e saj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "gjatë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "gjë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shih" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "atë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "dy" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ka" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shikoni" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "më shumë" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "rresht" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "gojë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "simbol" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "vdes" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "probleme" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "bërtas" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "me përjashtim të" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shkroi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "farë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ton" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "qelizë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "besoj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ndoshta" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "marr" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "papritur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të llogarisë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "katrore" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "arsyeja" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "Gjatësia" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "përfaqësojnë" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "gjak" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "prek" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "u rrit" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "cent" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "përzierje" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ekipi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "tela" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kosto" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "humbur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kafe" 1000  keyword_sq.txt

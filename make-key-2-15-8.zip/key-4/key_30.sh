java -jar getLatinTag.jar sq  "me zë të lartë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pranverë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "vëzhguar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "bashkëtingëllore" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "komb" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fjalor" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "qumësht" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shpejtësi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "Metoda" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "organ" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "e bardhë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fëmijë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të fillojë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "eci" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shembull" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "lehtësuar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "letër" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "grup" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "gjithmonë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "muzikë" 1000  keyword_sq.txt

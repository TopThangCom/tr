java -jar getLatinTag.jar sq  "prerë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i sigurt" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shikojnë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ngjyra" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fytyrë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "dru" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kryesore" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "hapur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "duket" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "së bashku" 1000  keyword_sq.txt

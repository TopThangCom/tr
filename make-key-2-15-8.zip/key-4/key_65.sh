java -jar getLatinTag.jar sq  "segment" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "rob" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "duck" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i menjëhershëm" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "tregu" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "populloj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "zogth" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i dashur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "armik" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "përgjigjen" 1000  keyword_sq.txt

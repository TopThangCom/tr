java -jar getLatinTag.jar sq  "lojë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "barazojnë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "Miss" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "solli" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ngrohjes" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "borë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "gomë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "sjellë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "po" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i largët" 1000  keyword_sq.txt

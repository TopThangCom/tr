java -jar getLatinTag.jar sq  "ndryshoj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kthesë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shkaku" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mesatare" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "para" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "veprim" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "drejtë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "djalë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "vjetër" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i njëjtë" 1000  keyword_sq.txt

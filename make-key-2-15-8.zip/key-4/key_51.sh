java -jar getLatinTag.jar sq  "yndyrë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kënaqur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "origjinal" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pjesa" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "stacion" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "bukë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ngarkuar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i duhur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "bar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "Oferta" 1000  keyword_sq.txt

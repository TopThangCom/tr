java -jar getLatinTag.jar sq  "fshij" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "tub" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i famshëm" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "dollar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "lumë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "frikë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pamje" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i hollë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "trekëndësh" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "planet" 1000  keyword_sq.txt

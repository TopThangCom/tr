java -jar getLatinTag.jar sq  "i frikësuar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "motra" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "çeliku" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "diskutuar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "përpara" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ngjashme" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "udhëzojë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "përvojë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mollë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "blerë" 1000  keyword_sq.txt

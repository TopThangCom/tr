java -jar getLatinTag.jar sq  "lakuriq nate" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "më tepër" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "turmë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "misri" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të krahasuar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "poemë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "string" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "zile" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "varet" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mish" 1000  keyword_sq.txt

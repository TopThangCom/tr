java -jar getLatinTag.jar sq  "i vetëm" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ushtrim" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kapur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mali" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "uroj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "qiell" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "bordi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "lumturi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "dimrit" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "pyetje" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ndodhë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "i plotë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "anije" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "zonë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "gjysmë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shkëmb" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "zjarri" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "jug" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "problemi" 1000  keyword_sq.txt

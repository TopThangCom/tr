java -jar getLatinTag.jar sq  "vizitë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "e kaluara" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "e butë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "argëtim" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ndritshme" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "gazit" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mot" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "muaj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "milion" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mbajnë" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "javë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "përfundimtar" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "dha" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "e gjelbër" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "oh" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "shpejtë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "zhvilloj" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "oqean" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "ngrohtë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pa pagesë" 1000  keyword_sq.txt

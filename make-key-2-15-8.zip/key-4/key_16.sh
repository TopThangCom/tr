java -jar getLatinTag.jar sq  "rrudhë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "vrimë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kërcejnë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "tetë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fshati" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "takohen" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "rrënjë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "blej" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "të rritur" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "zgjidhur" 1000  keyword_sq.txt

java -jar getLatinTag.jar sq  "sy" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kurrë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fundit" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "le të" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "mendimi" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "qytet" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "pemë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "kalojnë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "fermë" 1000  keyword_sq.txt
java -jar getLatinTag.jar sq  "vështirë" 1000  keyword_sq.txt

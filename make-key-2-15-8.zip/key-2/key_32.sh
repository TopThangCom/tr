java -jar getLatinTag.jar hu  "gyűrű" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "betű" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "rovar" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "fogott" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "időszak" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "azt mutatják," 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "rádió" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "küllős" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "atomnak" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "emberi" 1000  keyword_hu.txt

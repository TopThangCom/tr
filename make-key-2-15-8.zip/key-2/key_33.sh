java -jar getLatinTag.jar hu  "személy" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "pénz" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "szolgál" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "jelenik meg" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "térkép" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "eső" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "szabály" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "kormány" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "húzza" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "hideg" 1000  keyword_hu.txt

java -jar getLatinTag.jar hu  "ismétlés" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "előkészítése" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "só" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "orr" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "többes" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "harag" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "igény" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "kontinens" 1000  keyword_hu.txt

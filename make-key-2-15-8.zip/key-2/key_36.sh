java -jar getLatinTag.jar hu  "hazugság" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "üt" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "gerjeszti" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "természetes" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "nézet" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "értelme" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "tőke" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "nem fog" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "szék" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "veszély" 1000  keyword_hu.txt

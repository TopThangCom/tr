java -jar getLatinTag.jar hu  "beszél" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "súly" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "általános" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "jég" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "kör" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "pár" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "többek között" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "szakadék" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "szótag" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "úgy érezte," 1000  keyword_hu.txt

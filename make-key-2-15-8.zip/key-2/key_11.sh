java -jar getLatinTag.jar hu  "piros" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "lista" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "bár" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "úgy érzi," 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "beszélgetés" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "madár" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "hamar" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "test" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "kutya" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "család" 1000  keyword_hu.txt

java -jar getLatinTag.jar hu  "az enyém" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "nyakkendő" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "be" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "nagyobb" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "friss" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "keresés" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "küld" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "sárga" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "pisztoly" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "nyomtatás" 1000  keyword_hu.txt

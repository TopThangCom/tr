java -jar getLatinTag.jar hu  "kellene" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "ország" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "talált" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "válasz" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "iskola" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "nő" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "tanulmány" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "még mindig" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "tanul" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "növény" 1000  keyword_hu.txt

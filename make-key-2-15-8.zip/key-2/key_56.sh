java -jar getLatinTag.jar hu  "intézkedik" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "tábor" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "feltalál" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "pamut" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "születése" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "határozza meg" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "liter" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "kilenc" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "teherautó" 1000  keyword_hu.txt
java -jar getLatinTag.jar hu  "zaj" 1000  keyword_hu.txt

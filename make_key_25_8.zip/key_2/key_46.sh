java -jar getLatinTag.jar in hi  "मेरे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अधिक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पता" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पानी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "से" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "उनके" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "समय" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अगर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "होगा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कैसे" 1000  keyword_hi.txt

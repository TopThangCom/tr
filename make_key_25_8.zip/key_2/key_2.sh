java -jar getLatinTag.jar in hi  "ऊपर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कभी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लाल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सूची" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हालांकि" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "कहा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "एक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रत्येक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बता" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "करता है" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "भी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "खेलने" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "छोटे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अंत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "डाल" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "सदैव" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "संगीत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "उन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दोनों" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मार्क" 1000  keyword_hi.txt

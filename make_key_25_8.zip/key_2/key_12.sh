java -jar getLatinTag.jar in hi  "शहर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पेड़" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "खेत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कठिन" 1000  keyword_hi.txt

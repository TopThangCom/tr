java -jar getLatinTag.jar in hi  "अक्सर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पत्र" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जब तक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मील" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नदी" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "टायर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लाना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हां" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दूर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "भरने" 1000  keyword_hi.txt

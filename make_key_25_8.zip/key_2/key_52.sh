java -jar getLatinTag.jar in hi  "समुद्र" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आकर्षित" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "छोड़ा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "देर से" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चलाने" 1000  keyword_hi.txt

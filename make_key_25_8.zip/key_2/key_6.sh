java -jar getLatinTag.jar in hi  "गीत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नाप" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दरवाजा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "उत्पाद" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "काला" 1000  keyword_hi.txt

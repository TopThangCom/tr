java -jar getLatinTag.jar in hi  "रॉक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आदेश" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आग" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दक्षिण" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "समस्या" 1000  keyword_hi.txt

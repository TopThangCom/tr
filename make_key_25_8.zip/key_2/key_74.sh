java -jar getLatinTag.jar in hi  "अधिनियम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "क्यों" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पूछना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पुरुषों" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "परिवर्तन" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "नई" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "काम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हिस्सा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लेना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्राप्त" 1000  keyword_hi.txt

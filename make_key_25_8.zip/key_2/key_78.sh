java -jar getLatinTag.jar in hi  "लकड़ी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मुख्य" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "खुला" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रतीत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "एक साथ" 1000  keyword_hi.txt

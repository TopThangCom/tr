java -jar getLatinTag.jar in hi  "रास्ता" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "के बारे में" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कई" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तो" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "उन्हें" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "कुत्ते" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "परिवार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रत्यक्ष" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ढोंग" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "छोड़" 1000  keyword_hi.txt

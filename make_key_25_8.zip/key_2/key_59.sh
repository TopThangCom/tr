java -jar getLatinTag.jar in hi  "आप" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "या" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "था" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "की" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तक" 1000  keyword_hi.txt

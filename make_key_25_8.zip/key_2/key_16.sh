java -jar getLatinTag.jar in hi  "जादू" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जोड़" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "और भी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "भूमि" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "यहाँ" 1000  keyword_hi.txt

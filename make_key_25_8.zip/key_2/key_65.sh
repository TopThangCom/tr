java -jar getLatinTag.jar in hi  "पक्ष" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "गया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अब" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लगता है" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सिर" 1000  keyword_hi.txt

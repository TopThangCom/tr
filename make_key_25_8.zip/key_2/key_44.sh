java -jar getLatinTag.jar in hi  "पूर्व" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "रंग" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "भाषा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "के बीच" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "इकाई" 1000  keyword_hi.txt

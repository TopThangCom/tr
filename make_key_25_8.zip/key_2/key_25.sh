java -jar getLatinTag.jar in hi  "चाहिए" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बड़ा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "उच्च" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ऐसा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "का पालन करें" 1000  keyword_hi.txt

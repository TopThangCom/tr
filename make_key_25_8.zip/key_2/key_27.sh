java -jar getLatinTag.jar in hi  "कार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पैर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "देखभाल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दूसरा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पर्याप्त" 1000  keyword_hi.txt

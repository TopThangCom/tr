java -jar getLatinTag.jar in hi  "टुकड़ा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बताया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पता था" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पास" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "के बाद से" 1000  keyword_hi.txt

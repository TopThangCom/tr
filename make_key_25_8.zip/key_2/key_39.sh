java -jar getLatinTag.jar in hi  "चलना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "उदाहरण" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आसानी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कागज" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "समूह" 1000  keyword_hi.txt

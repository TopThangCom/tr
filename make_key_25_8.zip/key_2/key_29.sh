java -jar getLatinTag.jar in hi  "गुणा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कुछ नहीं" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कोर्स" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "रहना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पहिया" 1000  keyword_hi.txt

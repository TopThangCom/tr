java -jar getLatinTag.jar in hi  "उसके" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लंबे समय तक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बात" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "देखना" 1000  keyword_hi.txt

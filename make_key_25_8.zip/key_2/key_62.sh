java -jar getLatinTag.jar in hi  "सूरज" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "के बीच" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "राज्य" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "रखना" 1000  keyword_hi.txt

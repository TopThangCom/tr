java -jar getLatinTag.jar in hi  "शुरुआत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हो सकता है" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कहानी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "देखा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दूर" 1000  keyword_hi.txt

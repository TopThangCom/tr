java -jar getLatinTag.jar in hi  "जगह" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "निर्मित" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जीना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जहां" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "के बाद" 1000  keyword_hi.txt

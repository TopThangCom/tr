java -jar getLatinTag.jar in hi  "घर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तस्वीर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कोशिश" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हमें" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "फिर" 1000  keyword_hi.txt

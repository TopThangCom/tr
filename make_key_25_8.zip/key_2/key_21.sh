java -jar getLatinTag.jar in hi  "कॉल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पहले" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कौन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मई" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नीचे" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "संख्या" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ध्वनि" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नहीं" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सबसे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लोग" 1000  keyword_hi.txt

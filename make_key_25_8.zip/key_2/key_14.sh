java -jar getLatinTag.jar in hi  "वहाँ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जब" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ऊपर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "उपयोग" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अपने" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "होना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पूरा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जहाज" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "क्षेत्र" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आधा" 1000  keyword_hi.txt

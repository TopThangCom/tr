java -jar getLatinTag.jar in hi  "ऐसा नहीं" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जबकि" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रेस" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "करीब" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "रात" 1000  keyword_hi.txt

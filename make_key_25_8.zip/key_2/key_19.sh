java -jar getLatinTag.jar in hi  "सेट" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तीन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चाहते हैं" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हवा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अच्छी तरह से" 1000  keyword_hi.txt

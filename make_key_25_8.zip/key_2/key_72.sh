java -jar getLatinTag.jar in hi  "अगला" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सफेद" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बच्चों" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रारंभ करना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मिला" 1000  keyword_hi.txt

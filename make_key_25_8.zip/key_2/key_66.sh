java -jar getLatinTag.jar in hi  "पुराना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "भी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "वही" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "वह" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सब" 1000  keyword_hi.txt

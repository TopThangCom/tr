java -jar getLatinTag.jar in hi  "सतह" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "गहरा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चांद" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "द्वीप" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पैर" 1000  keyword_hi.txt

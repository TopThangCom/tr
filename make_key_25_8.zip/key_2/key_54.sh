java -jar getLatinTag.jar in hi  "वर्ष" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शो" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अच्छा" 1000  keyword_hi.txt

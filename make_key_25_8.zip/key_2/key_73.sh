java -jar getLatinTag.jar in hi  "महान" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लगता है" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कहना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मदद" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कम" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "मुझे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हमारे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नीचे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नाम" 1000  keyword_hi.txt

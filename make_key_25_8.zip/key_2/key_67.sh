java -jar getLatinTag.jar in hi  "दिन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सकता है" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जाना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "किया" 1000  keyword_hi.txt

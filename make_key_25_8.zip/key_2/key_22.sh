java -jar getLatinTag.jar in hi  "पाया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जवाब" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "स्कूल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बढ़ने" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अध्ययन" 1000  keyword_hi.txt

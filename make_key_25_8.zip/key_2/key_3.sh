java -jar getLatinTag.jar in hi  "ले" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ले लिया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "विज्ञान" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "खाने" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कमरे" 1000  keyword_hi.txt

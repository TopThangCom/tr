java -jar getLatinTag.jar in hi  "बनाना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आत्म" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पृथ्वी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पिता" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "किसी भी" 1000  keyword_hi.txt

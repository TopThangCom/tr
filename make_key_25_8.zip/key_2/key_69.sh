java -jar getLatinTag.jar in hi  "बाहर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अन्य" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "थे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जो" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कर" 1000  keyword_hi.txt

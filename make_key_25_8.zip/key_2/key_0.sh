java -jar getLatinTag.jar in hi  "उसे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दो" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "है" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "देखो" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अधिक" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "रोक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "एक बार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आधार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सुनना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "घोड़ा" 1000  keyword_hi.txt

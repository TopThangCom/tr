java -jar getLatinTag.jar in hi  "सादे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लड़की" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हमेशा की तरह" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "युवा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तैयार" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "आम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सोना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "संभव" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "विमान" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जगह" 1000  keyword_hi.txt

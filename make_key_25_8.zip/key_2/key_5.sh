java -jar getLatinTag.jar in hi  "भागा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जाँच" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "खेल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आकार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "समानता" 1000  keyword_hi.txt

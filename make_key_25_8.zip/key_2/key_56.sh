java -jar getLatinTag.jar in hi  "इस" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "से" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "द्वारा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "गरम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शब्द" 1000  keyword_hi.txt

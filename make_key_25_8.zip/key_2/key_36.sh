java -jar getLatinTag.jar in hi  "असली" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जीवन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कुछ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "उत्तर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "किताब" 1000  keyword_hi.txt

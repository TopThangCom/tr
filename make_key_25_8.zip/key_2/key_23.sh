java -jar getLatinTag.jar in hi  "कटौती" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "यकीन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "घड़ी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "रंग" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चेहरा" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "लग रहा है" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "वार्ता" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पक्षी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शीघ्र" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शरीर" 1000  keyword_hi.txt

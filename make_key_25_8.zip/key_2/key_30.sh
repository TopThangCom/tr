java -jar getLatinTag.jar in hi  "आंख" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कभी नहीं" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पिछले" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चलो" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सोचा" 1000  keyword_hi.txt

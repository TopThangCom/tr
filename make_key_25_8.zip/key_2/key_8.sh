java -jar getLatinTag.jar in hi  "और" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "एक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "में" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कर सकते हैं" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "खड़े" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "खुद" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पेज" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चाहिए" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "देश" 1000  keyword_hi.txt

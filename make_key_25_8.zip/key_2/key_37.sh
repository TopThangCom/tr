java -jar getLatinTag.jar in hi  "पशु" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बिंदु" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मां" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दुनिया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "निकट" 1000  keyword_hi.txt

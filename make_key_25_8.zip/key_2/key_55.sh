java -jar getLatinTag.jar in hi  "लिखना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "होगा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जैसा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तो" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "इन" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "अब तक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सीखना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "संयंत्र" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कवर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "भोजन" 1000  keyword_hi.txt

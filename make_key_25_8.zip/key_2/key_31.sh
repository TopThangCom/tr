java -jar getLatinTag.jar in hi  "वे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हो" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "एक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "है" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "सूखा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आश्चर्य" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हंसी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हजार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पहले" 1000  keyword_hi.txt

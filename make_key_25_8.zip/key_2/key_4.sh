java -jar getLatinTag.jar in hi  "वापस" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "थोड़ा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "केवल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दौर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आदमी" 1000  keyword_hi.txt

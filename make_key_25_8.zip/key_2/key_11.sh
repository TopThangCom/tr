java -jar getLatinTag.jar in hi  "मतलब" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पहले" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चाल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सही" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लड़का" 1000  keyword_hi.txt

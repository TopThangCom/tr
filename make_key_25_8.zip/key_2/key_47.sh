java -jar getLatinTag.jar in hi  "चला गया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रकाश" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तरह" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बंद" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आवश्यकता" 1000  keyword_hi.txt

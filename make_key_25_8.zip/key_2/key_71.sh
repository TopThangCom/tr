java -jar getLatinTag.jar in hi  "था" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "के लिए" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हैं" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "साथ" 1000  keyword_hi.txt

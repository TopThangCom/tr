java -jar getLatinTag.jar in hi  "कम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अंक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "क्लास" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हवा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सवाल" 1000  keyword_hi.txt

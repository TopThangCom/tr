java -jar getLatinTag.jar in hi  "रेखा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अलग" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बारी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कारण" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ज्यादा" 1000  keyword_hi.txt

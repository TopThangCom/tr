java -jar getLatinTag.jar in hi  "घर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पढ़ा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हाथ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बंदरगाह" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बड़ा" 1000  keyword_hi.txt

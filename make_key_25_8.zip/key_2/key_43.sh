java -jar getLatinTag.jar in hi  "पूर्ण" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नीला" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "वस्तु" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तय" 1000  keyword_hi.txt

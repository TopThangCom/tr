java -jar getLatinTag.jar in hi  "दोस्त" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शुरू हुआ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "विचार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मछली" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पहाड़" 1000  keyword_hi.txt

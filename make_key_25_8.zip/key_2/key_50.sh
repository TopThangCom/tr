java -jar getLatinTag.jar in hi  "प्रणाली" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "व्यस्त" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "परीक्षण" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "रिकॉर्ड" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नाव" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "बहुत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "के माध्यम से" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बस" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "फार्म" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "वाक्य" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "जैसा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मैं" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "उसके" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कि" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "वह" 1000  keyword_hi.txt

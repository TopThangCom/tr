java -jar getLatinTag.jar in hi  "शीर्ष" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पूरे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "राजा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सड़क" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "इंच" 1000  keyword_hi.txt

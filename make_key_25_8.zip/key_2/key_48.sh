java -jar getLatinTag.jar in hi  "गरम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मिस" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लाया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "गर्मी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बर्फ" 1000  keyword_hi.txt

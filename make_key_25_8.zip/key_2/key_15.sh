java -jar getLatinTag.jar in hi  "लेकिन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "क्या" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कुछ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "है" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "यह" 1000  keyword_hi.txt

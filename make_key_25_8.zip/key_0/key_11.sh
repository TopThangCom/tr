java -jar getLatinTag.jar jp ja  "間に" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "百" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "五" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "覚えている" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ステップ" 1000  keyword_ja.txt

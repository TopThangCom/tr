java -jar getLatinTag.jar jp ja  "ドライブ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "立っていた" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "含む" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "フロント" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "教える" 1000  keyword_ja.txt

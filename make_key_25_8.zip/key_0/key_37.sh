java -jar getLatinTag.jar jp ja  "スター" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ボックス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "名詞" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "フィールド" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "残り" 1000  keyword_ja.txt

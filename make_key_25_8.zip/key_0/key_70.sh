java -jar getLatinTag.jar jp ja  "分数" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "森" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "座る" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "レース" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "窓" 1000  keyword_ja.txt

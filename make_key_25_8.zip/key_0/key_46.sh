java -jar getLatinTag.jar jp ja  "見える" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "道路" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "マップ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "雨" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ルール" 1000  keyword_ja.txt

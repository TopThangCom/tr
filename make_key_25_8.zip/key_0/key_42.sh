java -jar getLatinTag.jar jp ja  "選ぶ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "落ちた" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "フィット" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "流れ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "フェア" 1000  keyword_ja.txt

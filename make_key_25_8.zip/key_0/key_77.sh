java -jar getLatinTag.jar jp ja  "明確な" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "テール" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "作る" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "事実" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "スペース" 1000  keyword_ja.txt

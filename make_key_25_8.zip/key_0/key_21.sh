java -jar getLatinTag.jar jp ja  "飛ぶ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "落ちる" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "鉛" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "泣く" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "暗い" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "エッジ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "看板" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "訪問" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "過去" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ソフト" 1000  keyword_ja.txt

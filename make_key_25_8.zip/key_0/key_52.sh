java -jar getLatinTag.jar jp ja  "クイック" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "開発する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "海" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "暖かい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "無料で" 1000  keyword_ja.txt

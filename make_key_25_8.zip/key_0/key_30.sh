java -jar getLatinTag.jar jp ja  "ブラウン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "着用" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "庭" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "等しい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "送信された" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "ストレート" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "子音" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "国家" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "辞書" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ミルク" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "早い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ホールド" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "西" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "地面" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "関心" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "オイル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "血" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "触れる" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "成長した" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "セント" 1000  keyword_ja.txt

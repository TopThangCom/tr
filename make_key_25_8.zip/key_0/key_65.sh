java -jar getLatinTag.jar jp ja  "AM" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "現在" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "重い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ダンス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "エンジン" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "保管" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ガラス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "草" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "乳牛" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "仕事" 1000  keyword_ja.txt

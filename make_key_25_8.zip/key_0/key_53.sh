java -jar getLatinTag.jar jp ja  "ビット" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "海岸" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "コピー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "フレーズ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "サイレント" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "トーン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "参加する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "提案する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "クリーン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ブレーク" 1000  keyword_ja.txt

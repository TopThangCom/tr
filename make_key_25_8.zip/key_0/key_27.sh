java -jar getLatinTag.jar jp ja  "ビート" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "エキサイト" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ナチュラル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ビュー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "感覚" 1000  keyword_ja.txt

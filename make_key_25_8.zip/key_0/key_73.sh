java -jar getLatinTag.jar jp ja  "サイズ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "変える" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "落ち着く" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "話す" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "重さ" 1000  keyword_ja.txt

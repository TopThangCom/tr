java -jar getLatinTag.jar jp ja  "戦争" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "産む" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "に対する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "パターン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "遅い" 1000  keyword_ja.txt

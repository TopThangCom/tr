java -jar getLatinTag.jar jp ja  "セクション" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ドレス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "クラウド" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "驚き" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "静かな" 1000  keyword_ja.txt

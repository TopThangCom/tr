java -jar getLatinTag.jar jp ja  "期待する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "骨" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "レール" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "想像する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "提供する" 1000  keyword_ja.txt

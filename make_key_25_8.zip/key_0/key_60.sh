java -jar getLatinTag.jar jp ja  "含める" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "分割" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "音節" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "フェルト" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "壮大な" 1000  keyword_ja.txt

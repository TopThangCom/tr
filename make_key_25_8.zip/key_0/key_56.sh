java -jar getLatinTag.jar jp ja  "どちら" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "結果" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "燃やす" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "丘" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "金庫" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "スキン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "笑顔" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "しわ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "穴" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ジャンプ" 1000  keyword_ja.txt

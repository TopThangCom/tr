java -jar getLatinTag.jar jp ja  "ローン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "レッグ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "エクササイズ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "壁" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "キャッチ" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "センター" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "愛" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "人" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "マネー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "サーブ" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "スピード" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "方法" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "オルガン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "支払い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "年齢" 1000  keyword_ja.txt

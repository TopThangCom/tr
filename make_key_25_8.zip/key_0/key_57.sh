java -jar getLatinTag.jar jp ja  "ヒット" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "学生" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "コーナー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "パーティー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "サプライ" 1000  keyword_ja.txt

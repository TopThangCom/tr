java -jar getLatinTag.jar jp ja  "正しい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "できる" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ポンド" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "終わった" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "美しさ" 1000  keyword_ja.txt

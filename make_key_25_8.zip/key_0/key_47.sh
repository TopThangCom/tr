java -jar getLatinTag.jar jp ja  "支配する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "引っ張る" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "寒い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "予告" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "声" 1000  keyword_ja.txt

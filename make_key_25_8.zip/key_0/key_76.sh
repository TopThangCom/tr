java -jar getLatinTag.jar jp ja  "店" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "夏" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "列車" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "スリープ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "証明する" 1000  keyword_ja.txt

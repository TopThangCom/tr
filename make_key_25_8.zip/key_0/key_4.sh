java -jar getLatinTag.jar jp ja  "同意する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "このようにして" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "優しい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "女" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "キャプテン" 1000  keyword_ja.txt

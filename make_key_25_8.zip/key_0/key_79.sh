java -jar getLatinTag.jar jp ja  "耳" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ほかに" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "かなり" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "壊した" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ケース" 1000  keyword_ja.txt

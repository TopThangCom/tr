java -jar getLatinTag.jar jp ja  "メロディー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "旅" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "オフィス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "受け取る" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "行" 1000  keyword_ja.txt

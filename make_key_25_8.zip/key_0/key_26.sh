java -jar getLatinTag.jar jp ja  "冬" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "土" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "書かれた" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ワイルド" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "楽器" 1000  keyword_ja.txt

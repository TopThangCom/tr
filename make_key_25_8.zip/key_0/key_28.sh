java -jar getLatinTag.jar jp ja  "マウント" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "希望" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "空" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ボード" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "喜び" 1000  keyword_ja.txt

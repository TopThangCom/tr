java -jar getLatinTag.jar jp ja  "首都" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ないでしょう" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "椅子" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "危険" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "フルーツ" 1000  keyword_ja.txt

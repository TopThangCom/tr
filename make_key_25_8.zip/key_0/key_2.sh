java -jar getLatinTag.jar jp ja  "石" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "小さな" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "登る" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "涼しい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "デザイン" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "キャッチ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "期間" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "示す" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ラジオ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "スポーク" 1000  keyword_ja.txt

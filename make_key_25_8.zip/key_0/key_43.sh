java -jar getLatinTag.jar jp ja  "その" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "検索する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "リング" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "キャラクター" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "昆虫" 1000  keyword_ja.txt

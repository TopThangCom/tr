java -jar getLatinTag.jar jp ja  "万" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "クマ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "仕上げ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "幸せな" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "希望" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "銀行" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "集める" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "保存" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "コントロール" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "進" 1000  keyword_ja.txt

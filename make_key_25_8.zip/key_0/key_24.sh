java -jar getLatinTag.jar jp ja  "ユニット" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "パワー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "町" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "罰金" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "特定の" 1000  keyword_ja.txt

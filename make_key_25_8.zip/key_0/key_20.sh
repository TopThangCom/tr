java -jar getLatinTag.jar jp ja  "長さ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "表す" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "アート" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "テーマ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "地域" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "リーチ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "速い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "動詞" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "歌う" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "聞く" 1000  keyword_ja.txt

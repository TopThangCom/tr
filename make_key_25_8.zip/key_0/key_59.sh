java -jar getLatinTag.jar jp ja  "花" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "衣服を着せる" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "奇妙な" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "いなくなった" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "トレード" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "ボール" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "まだ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "波" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ドロップ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "心" 1000  keyword_ja.txt

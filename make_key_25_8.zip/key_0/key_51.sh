java -jar getLatinTag.jar jp ja  "アトム" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "人間" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "歴史" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "効果" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "エレクトリック" 1000  keyword_ja.txt

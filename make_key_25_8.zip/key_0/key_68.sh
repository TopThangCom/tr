java -jar getLatinTag.jar jp ja  "選ぶ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "突然の" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "カウント" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "広場" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "理由" 1000  keyword_ja.txt

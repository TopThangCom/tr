java -jar getLatinTag.jar jp ja  "楽しい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "明るい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ガス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "天候" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "月" 1000  keyword_ja.txt

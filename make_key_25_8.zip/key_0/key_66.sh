java -jar getLatinTag.jar jp ja  "貧しい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "たくさん" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "実験" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ボトム" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "キー" 1000  keyword_ja.txt

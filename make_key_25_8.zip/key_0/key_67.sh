java -jar getLatinTag.jar jp ja  "練習" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "別" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "難しい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "医師" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "どうぞ" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "守る" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "正午" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "作物" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "モダン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "要素" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "鉄" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "シングル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "スティック" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "フラット" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "個の" 1000  keyword_ja.txt

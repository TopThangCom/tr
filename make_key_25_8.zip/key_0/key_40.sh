java -jar getLatinTag.jar jp ja  "ハンドヘルド" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "髪" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "説明する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "料理人" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "床" 1000  keyword_ja.txt

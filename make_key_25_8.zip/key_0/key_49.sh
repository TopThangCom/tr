java -jar getLatinTag.jar jp ja  "エネルギー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "狩り" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ありそうな" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ベッド" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "兄" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "六" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "テーブル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "旅行" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "レス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "朝" 1000  keyword_ja.txt

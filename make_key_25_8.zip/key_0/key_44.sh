java -jar getLatinTag.jar jp ja  "赤ちゃん" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "人" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "村" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "大会" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ルート" 1000  keyword_ja.txt

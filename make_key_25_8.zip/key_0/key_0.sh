java -jar getLatinTag.jar jp ja  "スケール" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "騒々しい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "春" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "観察する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "子ども" 1000  keyword_ja.txt

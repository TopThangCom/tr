java -jar getLatinTag.jar jp ja  "一般" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "アイス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "問題" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "サークル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ペア" 1000  keyword_ja.txt

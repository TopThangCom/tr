java -jar getLatinTag.jar jp ja  "背の高い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "砂" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "土壌" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ロール" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "温度" 1000  keyword_ja.txt

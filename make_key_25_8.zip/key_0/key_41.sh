java -jar getLatinTag.jar jp ja  "買う" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "上げる" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "解く" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "金属" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "かどうか" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "指" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "業界" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "値" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "戦い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "うそ" 1000  keyword_ja.txt

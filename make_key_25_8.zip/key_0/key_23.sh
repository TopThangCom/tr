java -jar getLatinTag.jar jp ja  "口" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "正確な" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "シンボル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "死ぬ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "最低" 1000  keyword_ja.txt

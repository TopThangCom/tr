java -jar getLatinTag.jar jp ja  "マシン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ノート" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "待つ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "計画" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "図" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "ミックス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "チーム" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ワイヤー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "コスト" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "失われた" 1000  keyword_ja.txt

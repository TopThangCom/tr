java -jar getLatinTag.jar jp ja  "猫" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "世紀" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "考える" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "タイプ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "法則" 1000  keyword_ja.txt

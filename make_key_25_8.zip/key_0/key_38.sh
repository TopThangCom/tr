java -jar getLatinTag.jar jp ja  "聞いた" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ベスト" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "時間" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "良い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "真の" 1000  keyword_ja.txt

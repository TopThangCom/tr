java -jar getLatinTag.jar jp ja  "分" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "強い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "特別" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "心" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "背後に" 1000  keyword_ja.txt

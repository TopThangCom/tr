java -jar getLatinTag.jar jp ja  "週" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ファイナル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "与えた" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "緑" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ああ" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "女性" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "庭" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "上昇" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "悪い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "打撃" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "金持ち" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "厚い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "兵士" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "プロセス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "操作する" 1000  keyword_ja.txt

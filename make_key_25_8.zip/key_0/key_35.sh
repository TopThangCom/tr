java -jar getLatinTag.jar jp ja  "プッシュ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "7" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "パラグラフ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "第3" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "しなければならない" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "ポジション" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "アーム" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "広い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "帆" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "材料" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "ミドル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "殺す" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "息子" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "湖" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "瞬間" 1000  keyword_ja.txt

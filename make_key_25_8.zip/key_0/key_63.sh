java -jar getLatinTag.jar jp ja  "卵" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "乗る" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "セル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "信じる" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "たぶん" 1000  keyword_ja.txt

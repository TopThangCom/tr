java -jar getLatinTag.jar jp ja  "トラブル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "シャウト" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ただし" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "書いた" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "シード" 1000  keyword_ja.txt

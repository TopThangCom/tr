java -jar getLatinTag.jar jp ja  "十" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "シンプル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "いくつかの" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "母音" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "の方へ" 1000  keyword_ja.txt

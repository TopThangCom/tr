java -jar getLatinTag.jar kr ko  "위치" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "팔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "폭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "항해" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "재료" 1000  keyword_ko.txt

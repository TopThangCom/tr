java -jar getLatinTag.jar kr ko  "스타" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "상자" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "명사" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "필드" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "나머지" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "멜로디" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "여행" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "사무실" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "수신" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "행" 1000  keyword_ko.txt

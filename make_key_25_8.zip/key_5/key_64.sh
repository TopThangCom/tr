java -jar getLatinTag.jar kr ko  "피부" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "미소" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "주름" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "구멍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "점프" 1000  keyword_ko.txt

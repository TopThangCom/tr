java -jar getLatinTag.jar kr ko  "센터" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "사랑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "사람" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "돈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "봉사" 1000  keyword_ko.txt

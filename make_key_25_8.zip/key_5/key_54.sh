java -jar getLatinTag.jar kr ko  "기계" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "주의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "대기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "계획" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "그림" 1000  keyword_ko.txt

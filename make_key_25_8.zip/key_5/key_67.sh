java -jar getLatinTag.jar kr ko  "연습" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "별도의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "어려운" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "의사" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "제발" 1000  keyword_ko.txt

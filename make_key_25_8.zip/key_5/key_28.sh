java -jar getLatinTag.jar kr ko  "마운트" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "소원" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "하늘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "판" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "즐거움" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "은행" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "수집" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "저장" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "제어" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "소수점" 1000  keyword_ko.txt

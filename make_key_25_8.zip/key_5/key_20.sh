java -jar getLatinTag.jar kr ko  "길이" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "대표" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "예술" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "주제" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "지역" 1000  keyword_ko.txt

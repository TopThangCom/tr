java -jar getLatinTag.jar kr ko  "선택" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "하락" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "적합" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "흐름" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "박람회" 1000  keyword_ko.txt

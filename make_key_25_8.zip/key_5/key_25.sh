java -jar getLatinTag.jar kr ko  "초기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "개최" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "서쪽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "지상" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "관심" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "어디로" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "현재" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "무거운" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "댄스" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "엔진" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "개최" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "머리" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "설명" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "요리" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "바닥" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "꽃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "의복을 걸치다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "기이 한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "사라" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "무역" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "빨리" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "개발" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "대양" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "따뜻한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "무료" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "귀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "다른" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "아주" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "파산" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "경우" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "히트" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "학생" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "코너" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "파티" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "공급" 1000  keyword_ko.txt

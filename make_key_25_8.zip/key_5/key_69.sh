java -jar getLatinTag.jar kr ko  "전쟁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "누워" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "에 대하여" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "패턴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "느린" 1000  keyword_ko.txt

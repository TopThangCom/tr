java -jar getLatinTag.jar kr ko  "겨울" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "토" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "기록" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "야생" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "악기" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "주" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "최종" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "준" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "녹색" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "오" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "아가" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "팔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "마을" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "대회" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "루트" 1000  keyword_ko.txt

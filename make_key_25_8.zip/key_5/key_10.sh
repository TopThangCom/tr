java -jar getLatinTag.jar kr ko  "보호" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "정오" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "작물" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "현대" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "요소" 1000  keyword_ko.txt

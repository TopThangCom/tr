java -jar getLatinTag.jar kr ko  "드라이브" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "서" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "포함" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "앞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "가르쳐" 1000  keyword_ko.txt

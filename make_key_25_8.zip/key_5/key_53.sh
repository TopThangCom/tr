java -jar getLatinTag.jar kr ko  "비트" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "해안" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "복사" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "문구" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "침묵" 1000  keyword_ko.txt

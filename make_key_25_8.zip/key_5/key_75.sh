java -jar getLatinTag.jar kr ko  "범위" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "빠른" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "동사" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "노래" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "청취" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "비행" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "가을" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "지도" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "울음 소리" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "어두운" 1000  keyword_ko.txt

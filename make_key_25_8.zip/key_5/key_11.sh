java -jar getLatinTag.jar kr ko  "중" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "백" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "오" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "기억" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "단계" 1000  keyword_ko.txt

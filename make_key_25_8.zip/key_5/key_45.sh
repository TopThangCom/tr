java -jar getLatinTag.jar kr ko  "기대" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "골" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "레일" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "상상" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "제공" 1000  keyword_ko.txt

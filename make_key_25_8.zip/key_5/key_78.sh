java -jar getLatinTag.jar kr ko  "톤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "가입" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "제안" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "청소" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "단절" 1000  keyword_ko.txt

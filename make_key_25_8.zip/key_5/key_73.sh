java -jar getLatinTag.jar kr ko  "크기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "다양" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "정착" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이야기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "무게" 1000  keyword_ko.txt

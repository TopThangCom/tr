java -jar getLatinTag.jar kr ko  "선택" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "갑자기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "계산" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "광장" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이유" 1000  keyword_ko.txt

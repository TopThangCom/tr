java -jar getLatinTag.jar kr ko  "중" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "결과" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "구울" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "언덕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "안전한" 1000  keyword_ko.txt

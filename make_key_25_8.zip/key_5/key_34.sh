java -jar getLatinTag.jar kr ko  "아가씨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "야드" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "상승" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "나쁜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "타격" 1000  keyword_ko.txt

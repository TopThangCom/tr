java -jar getLatinTag.jar kr ko  "고독한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "다리" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "운동" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "벽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "캐치" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "단위" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "힘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "마을" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "잘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "어떤" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "갈색" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "착용" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "정원" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "동일" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "전송" 1000  keyword_ko.txt

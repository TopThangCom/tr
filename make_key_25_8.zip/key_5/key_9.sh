java -jar getLatinTag.jar kr ko  "분" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "강한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "특수" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "마음" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "뒤에" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "입" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "정확한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "기호" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "죽다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이상" 1000  keyword_ko.txt

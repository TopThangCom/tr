java -jar getLatinTag.jar kr ko  "중간" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "죽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "아들" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "호수" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "순간" 1000  keyword_ko.txt

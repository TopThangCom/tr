java -jar getLatinTag.jar kr ko  "돌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "작은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "등반" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "멋진" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "디자인" 1000  keyword_ko.txt

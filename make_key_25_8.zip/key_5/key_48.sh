java -jar getLatinTag.jar kr ko  "일반" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "얼음" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "문제" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "원" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "쌍" 1000  keyword_ko.txt

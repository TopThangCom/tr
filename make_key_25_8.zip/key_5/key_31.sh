java -jar getLatinTag.jar kr ko  "직선" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "자음" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "국민" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "사전" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "우유" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "혼합" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "팀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "와이어" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "비용" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "손실" 1000  keyword_ko.txt

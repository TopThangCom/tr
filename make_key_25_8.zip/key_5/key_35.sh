java -jar getLatinTag.jar kr ko  "푸시" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "일곱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "단락" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "세번째" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "하여야한다" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "이길" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "흥분" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "자연" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "보기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "의미" 1000  keyword_ko.txt

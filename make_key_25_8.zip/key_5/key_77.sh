java -jar getLatinTag.jar kr ko  "명확한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "꼬리" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "생산" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "사실" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "공간" 1000  keyword_ko.txt

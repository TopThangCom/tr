java -jar getLatinTag.jar kr ko  "상점" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "여름" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "기차" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "잠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "증명" 1000  keyword_ko.txt

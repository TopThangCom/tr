java -jar getLatinTag.jar kr ko  "분수" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "숲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "앉아" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "레이스" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "창" 1000  keyword_ko.txt

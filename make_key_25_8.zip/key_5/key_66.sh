java -jar getLatinTag.jar kr ko  "가난한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "많은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "실험" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "바닥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "키" 1000  keyword_ko.txt

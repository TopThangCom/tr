java -jar getLatinTag.jar kr ko  "누구의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "위치" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "링" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "문자" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "곤충" 1000  keyword_ko.txt

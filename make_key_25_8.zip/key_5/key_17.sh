java -jar getLatinTag.jar kr ko  "풍부한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "두께" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "군인" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "과정" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "운영" 1000  keyword_ko.txt

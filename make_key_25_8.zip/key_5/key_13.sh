java -jar getLatinTag.jar kr ko  "육" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "나타난" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "여행" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이하" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "아침" 1000  keyword_ko.txt

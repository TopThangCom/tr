java -jar getLatinTag.jar kr ko  "손가락" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "산업" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "값" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "싸움" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "거짓말" 1000  keyword_ko.txt

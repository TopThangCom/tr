java -jar getLatinTag.jar kr ko  "에너지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "사냥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "가능성" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "침대" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "형제" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "자본" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "하지 않습니다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "의자" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "위험" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "과일" 1000  keyword_ko.txt

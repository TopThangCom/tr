java -jar getLatinTag.jar kr ko  "유지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "유리" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "잔디" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "소" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "작업" 1000  keyword_ko.txt

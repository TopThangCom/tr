java -jar getLatinTag.jar kr ko  "만" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "곰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "끝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "행복" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "기대" 1000  keyword_ko.txt

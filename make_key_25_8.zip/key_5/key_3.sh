java -jar getLatinTag.jar kr ko  "재미" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "밝은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "가스" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "날씨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "개월" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "기름" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "피" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "터치" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "성장" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "센트" 1000  keyword_ko.txt

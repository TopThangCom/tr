java -jar getLatinTag.jar kr ko  "표시" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "도로" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "지도" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "비" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "규칙" 1000  keyword_ko.txt

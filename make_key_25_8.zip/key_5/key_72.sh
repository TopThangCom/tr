java -jar getLatinTag.jar kr ko  "수고" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "소리" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "제외" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "썼다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "씨앗" 1000  keyword_ko.txt

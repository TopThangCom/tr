java -jar getLatinTag.jar kr ko  "규모" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "큰 소리로" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "봄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "관찰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "아이" 1000  keyword_ko.txt

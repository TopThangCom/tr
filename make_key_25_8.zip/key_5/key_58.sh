java -jar getLatinTag.jar kr ko  "고양이" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "세기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "고려" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "유형" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "법" 1000  keyword_ko.txt

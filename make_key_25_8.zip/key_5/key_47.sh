java -jar getLatinTag.jar kr ko  "적용" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "당겨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "감기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "예고" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "음성" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "공" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "아직" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "파" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "드롭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "마음" 1000  keyword_ko.txt

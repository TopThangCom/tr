java -jar getLatinTag.jar kr ko  "들어" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "가장" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "시간" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "더" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "사실" 1000  keyword_ko.txt

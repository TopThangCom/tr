java -jar getLatinTag.jar kr ko  "열" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "간단한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "여러" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "모음" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "방향" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "철" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "단일" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "스틱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "플랫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "스물" 1000  keyword_ko.txt

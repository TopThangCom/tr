java -jar getLatinTag.jar kr ko  "적발" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "기간" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "표시" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "라디오" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이야기" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "정확한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "수" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "파운드" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "완료" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "아름다움" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "키" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "모래" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "토양" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "롤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "온도" 1000  keyword_ko.txt

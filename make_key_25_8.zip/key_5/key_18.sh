java -jar getLatinTag.jar kr ko  "속도" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "방법" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "기관" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "지불" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "연령" 1000  keyword_ko.txt

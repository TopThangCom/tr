java -jar getLatinTag.jar kr ko  "계란" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "타고" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "셀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "생각" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "어쩌면" 1000  keyword_ko.txt

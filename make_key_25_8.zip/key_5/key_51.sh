java -jar getLatinTag.jar kr ko  "원자" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "인간" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "역사" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "효과" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "전기" 1000  keyword_ko.txt

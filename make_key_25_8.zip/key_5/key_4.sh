java -jar getLatinTag.jar kr ko  "동의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "따라서" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "부드러운" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "여성" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "주장" 1000  keyword_ko.txt

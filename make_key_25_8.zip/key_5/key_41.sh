java -jar getLatinTag.jar kr ko  "사기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "인상" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "해결" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "금속" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "여부" 1000  keyword_ko.txt

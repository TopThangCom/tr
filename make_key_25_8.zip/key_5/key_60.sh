java -jar getLatinTag.jar kr ko  "포함" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "분할" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "음절" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "느낌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "그랜드" 1000  keyword_ko.txt

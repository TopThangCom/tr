java -jar getLatinTag.jar kr ko  "섹션" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "드레스" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "구름" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "놀람" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "조용한" 1000  keyword_ko.txt

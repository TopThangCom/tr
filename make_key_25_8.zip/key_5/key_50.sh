java -jar getLatinTag.jar kr ko  "에지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "로그인" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "방문" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "지난" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "소프트" 1000  keyword_ko.txt

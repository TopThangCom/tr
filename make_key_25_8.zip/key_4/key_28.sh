java -jar getLatinTag.jar kr ko  "대신" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "건조" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "궁금" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "웃음" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "천" 1000  keyword_ko.txt

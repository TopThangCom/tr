java -jar getLatinTag.jar kr ko  "그" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "쓰기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "것" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "같은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "그래서" 1000  keyword_ko.txt

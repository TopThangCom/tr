java -jar getLatinTag.jar kr ko  "참조" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "그" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "두" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "봐" 1000  keyword_ko.txt

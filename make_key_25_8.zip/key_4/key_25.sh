java -jar getLatinTag.jar kr ko  "여기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "해야" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "큰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "높은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이러한" 1000  keyword_ko.txt

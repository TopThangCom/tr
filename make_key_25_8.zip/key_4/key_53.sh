java -jar getLatinTag.jar kr ko  "문제" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "조각" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이야기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "알고" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "통과" 1000  keyword_ko.txt

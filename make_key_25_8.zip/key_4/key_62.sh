java -jar getLatinTag.jar kr ko  "음식" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "일" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "네" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "사이" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "상태" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "변경" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "갔다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "빛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "종류" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "오프" 1000  keyword_ko.txt

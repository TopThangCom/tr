java -jar getLatinTag.jar kr ko  "로" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "나는" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "그의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "그" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "그" 1000  keyword_ko.txt

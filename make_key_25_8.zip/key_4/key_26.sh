java -jar getLatinTag.jar kr ko  "그룹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "항상" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "음악" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "그" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "모두" 1000  keyword_ko.txt

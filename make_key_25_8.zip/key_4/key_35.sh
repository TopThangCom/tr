java -jar getLatinTag.jar kr ko  "반" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "바위" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "주문" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "화재" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "남쪽" 1000  keyword_ko.txt

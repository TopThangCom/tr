java -jar getLatinTag.jar kr ko  "있어" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "도보" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "예" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "완화" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "종이" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "눈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "타이어" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "가져" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "예" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "먼" 1000  keyword_ko.txt

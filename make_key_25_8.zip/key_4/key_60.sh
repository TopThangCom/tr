java -jar getLatinTag.jar kr ko  "필요가있다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "집" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "사진" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "시험" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "우리" 1000  keyword_ko.txt

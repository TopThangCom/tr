java -jar getLatinTag.jar kr ko  "전" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "실행" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "확인" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "게임" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "모양" 1000  keyword_ko.txt

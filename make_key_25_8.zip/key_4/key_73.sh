java -jar getLatinTag.jar kr ko  "문장" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "큰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "생각" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "말" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "도움" 1000  keyword_ko.txt

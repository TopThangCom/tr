java -jar getLatinTag.jar kr ko  "블랙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "짧은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "숫자" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "클래스" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "바람" 1000  keyword_ko.txt

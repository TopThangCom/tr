java -jar getLatinTag.jar kr ko  "까지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "바다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "그리" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "왼쪽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "후반" 1000  keyword_ko.txt

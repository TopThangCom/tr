java -jar getLatinTag.jar kr ko  "큰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "철자" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "추가" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "도" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "땅" 1000  keyword_ko.txt

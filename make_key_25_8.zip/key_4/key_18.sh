java -jar getLatinTag.jar kr ko  "도착" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "장소" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "만든" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "살고있다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "어디에" 1000  keyword_ko.txt

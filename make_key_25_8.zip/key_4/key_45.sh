java -jar getLatinTag.jar kr ko  "머리" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "서" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "자신의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "페이지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "해야" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "그들" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "있다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "에" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "일" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이" 1000  keyword_ko.txt

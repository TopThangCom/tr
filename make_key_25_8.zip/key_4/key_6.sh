java -jar getLatinTag.jar kr ko  "떠나" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "노래" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "측정" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "문" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "제품" 1000  keyword_ko.txt

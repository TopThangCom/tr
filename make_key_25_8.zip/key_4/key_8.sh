java -jar getLatinTag.jar kr ko  "에" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "과" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "에" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "우리" 1000  keyword_ko.txt

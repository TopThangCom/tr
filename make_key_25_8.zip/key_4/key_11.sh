java -jar getLatinTag.jar kr ko  "많은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "의미" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이전" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "움직임" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "바로" 1000  keyword_ko.txt

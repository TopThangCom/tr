java -jar getLatinTag.jar kr ko  "동일시" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "뜨거운" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "미스" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "가져" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "열" 1000  keyword_ko.txt

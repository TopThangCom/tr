java -jar getLatinTag.jar kr ko  "하지만" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "무엇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "다소" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "그" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "몸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "개" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "가족" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "직접" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "포즈" 1000  keyword_ko.txt

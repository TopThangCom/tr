java -jar getLatinTag.jar kr ko  "함께" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "다음" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "흰색" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "어린이" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "시작" 1000  keyword_ko.txt

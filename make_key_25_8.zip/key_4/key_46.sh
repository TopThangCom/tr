java -jar getLatinTag.jar kr ko  "사람들" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "내" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이상" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "알고" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "물" 1000  keyword_ko.txt

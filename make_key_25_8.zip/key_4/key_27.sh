java -jar getLatinTag.jar kr ko  "강" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "자동차" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "피트" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "주의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "초" 1000  keyword_ko.txt

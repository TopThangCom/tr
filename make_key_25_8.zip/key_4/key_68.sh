java -jar getLatinTag.jar kr ko  "결정" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "표면" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "깊은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "달" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "섬" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "연구" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "여전히" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "학습" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "공장" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "덮개" 1000  keyword_ko.txt

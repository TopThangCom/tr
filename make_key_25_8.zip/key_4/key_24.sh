java -jar getLatinTag.jar kr ko  "산" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "중지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "한 번" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "기본" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "듣다" 1000  keyword_ko.txt

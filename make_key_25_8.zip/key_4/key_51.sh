java -jar getLatinTag.jar kr ko  "당신의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "방법" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "에 대한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "많은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "다음" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "넣어" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "홈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "읽기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "손" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "포트" 1000  keyword_ko.txt

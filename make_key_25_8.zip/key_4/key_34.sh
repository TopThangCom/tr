java -jar getLatinTag.jar kr ko  "방법" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "말했다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "각" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이야기" 1000  keyword_ko.txt

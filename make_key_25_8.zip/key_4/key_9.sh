java -jar getLatinTag.jar kr ko  "충분히" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "일반" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "소녀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "보통" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "젊은" 1000  keyword_ko.txt

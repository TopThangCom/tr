java -jar getLatinTag.jar kr ko  "마르크" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "자주" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "편지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "까지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "마일" 1000  keyword_ko.txt

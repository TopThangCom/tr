java -jar getLatinTag.jar kr ko  "질문" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "일" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "완료" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "배" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "지역" 1000  keyword_ko.txt

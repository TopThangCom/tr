java -jar getLatinTag.jar kr ko  "이" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "부터" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "에 의해" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "뜨거운" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "단어" 1000  keyword_ko.txt

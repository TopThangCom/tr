java -jar getLatinTag.jar kr ko  "더" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "일" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "수" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이동" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "올" 1000  keyword_ko.txt

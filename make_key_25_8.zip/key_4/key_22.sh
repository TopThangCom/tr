java -jar getLatinTag.jar kr ko  "국가" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "발견" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "답변" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "학교" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "성장" 1000  keyword_ko.txt

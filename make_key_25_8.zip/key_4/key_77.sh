java -jar getLatinTag.jar kr ko  "낮은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "온라인" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "차이" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "회전" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "원인" 1000  keyword_ko.txt

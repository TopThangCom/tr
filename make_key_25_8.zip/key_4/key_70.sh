java -jar getLatinTag.jar kr ko  "실행" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "하지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "반면" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "키를 누릅니다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "가까이" 1000  keyword_ko.txt

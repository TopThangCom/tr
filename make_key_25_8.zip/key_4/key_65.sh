java -jar getLatinTag.jar kr ko  "아래로" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "측면" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "하고" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "지금" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "발견" 1000  keyword_ko.txt

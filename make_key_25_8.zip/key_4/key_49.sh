java -jar getLatinTag.jar kr ko  "보트" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "공통의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "금" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "가능한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "비행기" 1000  keyword_ko.txt

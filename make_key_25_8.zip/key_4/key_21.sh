java -jar getLatinTag.jar kr ko  "보다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "통화" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "첫째" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "사람" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "수도" 1000  keyword_ko.txt

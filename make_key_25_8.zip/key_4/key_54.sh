java -jar getLatinTag.jar kr ko  "사람" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "년" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "온" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "쇼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "모든" 1000  keyword_ko.txt

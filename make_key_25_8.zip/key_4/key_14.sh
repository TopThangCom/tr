java -jar getLatinTag.jar kr ko  "모든" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "그곳에" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "때" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "올라" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "사용" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "발" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "시스템" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "바쁜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "테스트" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "기록" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "그래도" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "느낌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이야기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "조류" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "곧" 1000  keyword_ko.txt

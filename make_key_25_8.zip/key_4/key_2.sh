java -jar getLatinTag.jar kr ko  "준비된" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "위" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "지금까지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "빨간색" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "표" 1000  keyword_ko.txt

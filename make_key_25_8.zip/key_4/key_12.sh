java -jar getLatinTag.jar kr ko  "생각" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "도시" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "트리" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "교차" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "농장" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "유지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "눈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "결코" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "마지막" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "하자" 1000  keyword_ko.txt

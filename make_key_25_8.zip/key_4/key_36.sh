java -jar getLatinTag.jar kr ko  "밤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "실제" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "생활" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "조금" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "북" 1000  keyword_ko.txt

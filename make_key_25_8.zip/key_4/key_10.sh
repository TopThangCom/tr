java -jar getLatinTag.jar kr ko  "이름" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "대단히" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "를 통해" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "단지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "양식" 1000  keyword_ko.txt

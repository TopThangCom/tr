java -jar getLatinTag.jar kr ko  "모든" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "새로운" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "일" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "일부" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "소요" 1000  keyword_ko.txt

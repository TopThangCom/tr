java -jar getLatinTag.jar kr ko  "잘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "또한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "재생" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "작은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "끝" 1000  keyword_ko.txt

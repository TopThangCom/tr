java -jar getLatinTag.jar kr ko  "다시" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "동물" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "포인트" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "어머니" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "세계" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "이후" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "최고" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "전체" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "왕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "거리" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "말" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "컷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "확실한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "손목 시계" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "색" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "하지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "세트" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "세" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "필요" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "공기" 1000  keyword_ko.txt

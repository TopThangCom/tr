java -jar getLatinTag.jar kr ko  "책" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "수행" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "했다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "과학" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "식사" 1000  keyword_ko.txt

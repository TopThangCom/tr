java -jar getLatinTag.jar kr ko  "단단한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "시작" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "수도" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이야기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "톱" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "좋은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "나를" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "제공" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "우리의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "아래의" 1000  keyword_ko.txt

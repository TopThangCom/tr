java -jar getLatinTag.jar kr ko  "후" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "다시" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "작은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "만" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "둥근" 1000  keyword_ko.txt

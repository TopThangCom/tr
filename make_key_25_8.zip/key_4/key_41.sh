java -jar getLatinTag.jar kr ko  "방" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "친구" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "시작" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "아이디어" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "물고기" 1000  keyword_ko.txt

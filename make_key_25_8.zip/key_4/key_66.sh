java -jar getLatinTag.jar kr ko  "소년" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "늙은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "너무" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "동일" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "그녀" 1000  keyword_ko.txt

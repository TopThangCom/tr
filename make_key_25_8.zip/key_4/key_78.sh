java -jar getLatinTag.jar kr ko  "얼굴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "나무" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "주" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "오픈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "것" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "입력" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "동쪽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "페인트" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "언어" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "중" 1000  keyword_ko.txt

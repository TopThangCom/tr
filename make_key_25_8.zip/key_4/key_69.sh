java -jar getLatinTag.jar kr ko  "수" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "아웃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "다른" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "했다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "하는" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "했다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "에 대한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "에" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "아르" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "와" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "가까운" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "구축" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "자기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "지구" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "아버지" 1000  keyword_ko.txt

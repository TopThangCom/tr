java -jar getLatinTag.jar kr ko  "인치" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "곱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "아무것도" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "물론" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "유지" 1000  keyword_ko.txt

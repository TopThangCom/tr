java -jar getLatinTag.jar kr ko  "휠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "전체" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "힘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "푸른" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "객체" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "할" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "자신의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "시간" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "면" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "것" 1000  keyword_ko.txt

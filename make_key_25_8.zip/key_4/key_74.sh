java -jar getLatinTag.jar kr ko  "따라" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "행위" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "이유" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "문의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "남자" 1000  keyword_ko.txt

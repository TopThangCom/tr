java -jar getLatinTag.jar kr ko  "이들" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "그녀의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "긴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "확인" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "일" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "당신" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "또는" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "했다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "에" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "의" 1000  keyword_ko.txt

java -jar getLatinTag.jar kr ko  "한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "수" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "소리" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "없음" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko  "가장" 1000  keyword_ko.txt

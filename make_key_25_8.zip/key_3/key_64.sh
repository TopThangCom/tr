java -jar getLatinTag.jar in hi  "मुस्कान" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "क्रीज" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "छेद" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कूद" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बच्चे" 1000  keyword_hi.txt

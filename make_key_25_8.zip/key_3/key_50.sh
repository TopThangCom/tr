java -jar getLatinTag.jar in hi  "साइन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "यात्रा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अतीत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मुलायम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मज़ा" 1000  keyword_hi.txt

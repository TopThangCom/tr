java -jar getLatinTag.jar in hi  "एकल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "छड़ी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "फ्लैट" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बीस" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "त्वचा" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "उज्ज्वल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "गैस" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मौसम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "माह" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लाख" 1000  keyword_hi.txt

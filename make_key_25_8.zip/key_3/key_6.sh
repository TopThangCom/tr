java -jar getLatinTag.jar in hi  "नहीं होगा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कुर्सी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "खतरे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "फल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अमीर" 1000  keyword_hi.txt

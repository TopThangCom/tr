java -jar getLatinTag.jar in hi  "का प्रतिनिधित्व" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कला" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "विषय" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "क्षेत्र" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आकार" 1000  keyword_hi.txt

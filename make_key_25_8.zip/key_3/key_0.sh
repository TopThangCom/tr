java -jar getLatinTag.jar in hi  "जोर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "वसंत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "निरीक्षण" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बच्चे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सीधे" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "मानव" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "इतिहास" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रभाव" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बिजली" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "उम्मीद" 1000  keyword_hi.txt

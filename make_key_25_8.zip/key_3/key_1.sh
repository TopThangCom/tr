java -jar getLatinTag.jar in hi  "रेत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मिट्टी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "रोल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तापमान" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "उंगली" 1000  keyword_hi.txt

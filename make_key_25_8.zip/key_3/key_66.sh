java -jar getLatinTag.jar in hi  "बहुत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रयोग" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कुंजी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लोहा" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "खड़ा हुआ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "होते हैं" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सामने" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सिखाना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सप्ताह" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "उद्योग" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मूल्य" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लड़ाई" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "झूठ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हरा" 1000  keyword_hi.txt

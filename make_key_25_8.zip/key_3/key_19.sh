java -jar getLatinTag.jar in hi  "सक्षम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पाउंड" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "किया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सुंदरता" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ड्राइव" 1000  keyword_hi.txt

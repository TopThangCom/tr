java -jar getLatinTag.jar in hi  "बिजली" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शहर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ठीक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कुछ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मक्खी" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "बॉक्स" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "संज्ञा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "क्षेत्र" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बाकी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सही" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "पहनना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बगीचा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बराबर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "भेजा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चयन" 1000  keyword_hi.txt

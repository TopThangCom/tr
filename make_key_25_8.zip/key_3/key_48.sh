java -jar getLatinTag.jar in hi  "बर्फ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मामला" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "वृत्त" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जोड़ी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शामिल" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "नोट" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "इंतजार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "योजना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आंकड़ा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सितारा" 1000  keyword_hi.txt

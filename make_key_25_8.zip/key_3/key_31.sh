java -jar getLatinTag.jar in hi  "व्यंजन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "राष्ट्र" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शब्दकोश" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दूध" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "गति" 1000  keyword_hi.txt

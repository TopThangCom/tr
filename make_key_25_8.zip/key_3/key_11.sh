java -jar getLatinTag.jar in hi  "सौ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पांच" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "याद" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कदम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शीघ्र" 1000  keyword_hi.txt

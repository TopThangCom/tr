java -jar getLatinTag.jar in hi  "उठाना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "धातु" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चाहे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "धक्का" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "विभाजन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शब्दांश" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लगा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "भव्य" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "गेंद" 1000  keyword_hi.txt

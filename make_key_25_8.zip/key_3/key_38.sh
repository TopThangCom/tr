java -jar getLatinTag.jar in hi  "सर्वश्रेष्ठ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "घंटे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बेहतर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सच" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दौरान" 1000  keyword_hi.txt

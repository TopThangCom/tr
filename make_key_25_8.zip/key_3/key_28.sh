java -jar getLatinTag.jar in hi  "इच्छा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आसमान" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बोर्ड" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हर्ष" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सर्दियों" 1000  keyword_hi.txt

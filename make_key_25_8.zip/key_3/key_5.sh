java -jar getLatinTag.jar in hi  "पोशाक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बादल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आश्चर्य" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शांत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पत्थर" 1000  keyword_hi.txt

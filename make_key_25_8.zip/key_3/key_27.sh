java -jar getLatinTag.jar in hi  "उत्तेजित" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्राकृतिक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "देखें" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "भावना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "राजधानी" 1000  keyword_hi.txt

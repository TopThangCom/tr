java -jar getLatinTag.jar in hi  "भिन्न हो" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बसा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बोलना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "वजन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सामान्य" 1000  keyword_hi.txt

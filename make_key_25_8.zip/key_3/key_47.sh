java -jar getLatinTag.jar in hi  "खींच" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ठंड" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नोटिस" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आवाज" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ऊर्जा" 1000  keyword_hi.txt

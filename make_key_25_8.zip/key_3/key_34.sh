java -jar getLatinTag.jar in hi  "यार्ड" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "वृद्धि" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बुरा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "झटका" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तेल" 1000  keyword_hi.txt

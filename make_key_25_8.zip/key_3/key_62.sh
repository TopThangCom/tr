java -jar getLatinTag.jar in hi  "टीम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लागत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "खोया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ब्राउन" 1000  keyword_hi.txt

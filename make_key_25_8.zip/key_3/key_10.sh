java -jar getLatinTag.jar in hi  "दोपहर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "फसल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आधुनिक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तत्व" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मारना" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "तालिका" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "यात्रा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सुबह" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दस" 1000  keyword_hi.txt

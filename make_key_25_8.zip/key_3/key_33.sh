java -jar getLatinTag.jar in hi  "अवधि" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "संकेत मिलता है" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "रेडियो" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बात" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "एटम" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "मोटी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सैनिक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रक्रिया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "संचालित" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अभ्यास" 1000  keyword_hi.txt

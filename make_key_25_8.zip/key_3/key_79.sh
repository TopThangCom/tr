java -jar getLatinTag.jar in hi  "बाकी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "काफी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तोड़ दिया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मामले" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बीच" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "सरल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कई" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "स्वर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "की ओर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "युद्ध" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "इस प्रकार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कोमल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "महिला" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कप्तान" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अनुमान" 1000  keyword_hi.txt

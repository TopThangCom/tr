java -jar getLatinTag.jar in hi  "शामिल होने" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सुझाव है" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "साफ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तोड़" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "महिला" 1000  keyword_hi.txt

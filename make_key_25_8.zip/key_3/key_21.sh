java -jar getLatinTag.jar in hi  "गिरावट" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नेतृत्व" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "रोना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अंधेरा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मशीन" 1000  keyword_hi.txt

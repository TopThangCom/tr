java -jar getLatinTag.jar in hi  "पूंछ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "उत्पादन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तथ्य" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अंतरिक्ष" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सुना" 1000  keyword_hi.txt

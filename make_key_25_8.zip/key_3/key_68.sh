java -jar getLatinTag.jar in hi  "अचानक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "गिनती" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "वर्ग" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कारण" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लंबाई" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "गिर गया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "फिट" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रवाह" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मेला" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बैंक" 1000  keyword_hi.txt

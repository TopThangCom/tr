java -jar getLatinTag.jar in hi  "खून" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "स्पर्श" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बढ़ी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रतिशत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मिश्रण" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "पकड़" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पश्चिम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जमीन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ब्याज" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तक पहुँचने" 1000  keyword_hi.txt

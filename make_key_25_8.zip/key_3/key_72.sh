java -jar getLatinTag.jar in hi  "चिल्लाओ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सिवाय" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लिखा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बीज" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "स्वर" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "तेजी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "क्रिया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "गाना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सुनो" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "छह" 1000  keyword_hi.txt

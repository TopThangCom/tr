java -jar getLatinTag.jar in hi  "अंतिम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दिया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "हरे रंग" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ओह" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "त्वरित" 1000  keyword_hi.txt

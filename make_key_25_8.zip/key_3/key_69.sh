java -jar getLatinTag.jar in hi  "रखना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "के खिलाफ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पैटर्न" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "धीमी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "केंद्र" 1000  keyword_hi.txt

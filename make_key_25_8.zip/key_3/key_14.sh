java -jar getLatinTag.jar in hi  "हत्या" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बेटा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "झील" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पैमाने" 1000  keyword_hi.txt

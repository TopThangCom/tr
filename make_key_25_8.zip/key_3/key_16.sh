java -jar getLatinTag.jar in hi  "अभी तक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लहर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "ड्रॉप" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दिल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "AM" 1000  keyword_hi.txt

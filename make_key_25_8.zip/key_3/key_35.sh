java -jar getLatinTag.jar in hi  "सात" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पैरा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "तीसरे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "करेगा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आयोजित" 1000  keyword_hi.txt

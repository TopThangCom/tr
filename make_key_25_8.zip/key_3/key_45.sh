java -jar getLatinTag.jar in hi  "हड्डी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "रेल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कल्पना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रदान" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सहमत" 1000  keyword_hi.txt

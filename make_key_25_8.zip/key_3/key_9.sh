java -jar getLatinTag.jar in hi  "मजबूत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "विशेष" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पीछे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "स्पष्ट" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "कांच" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "घास" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "गाय" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "काम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बढ़त" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "प्यार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "व्यक्ति" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "धन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सेवा कर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रकट" 1000  keyword_hi.txt

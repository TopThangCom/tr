java -jar getLatinTag.jar in hi  "वर्तमान" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "भारी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नृत्य" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "इंजन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "स्थिति" 1000  keyword_hi.txt

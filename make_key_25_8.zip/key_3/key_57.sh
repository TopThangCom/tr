java -jar getLatinTag.jar in hi  "छात्र" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कोने" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पार्टी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आपूर्ति" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जिसका" 1000  keyword_hi.txt

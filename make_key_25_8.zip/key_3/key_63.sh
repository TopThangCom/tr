java -jar getLatinTag.jar in hi  "सवारी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सेल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "विश्वास है" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शायद" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "उठाओ" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "वन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बैठना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दौड़" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "खिड़की" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दुकान" 1000  keyword_hi.txt

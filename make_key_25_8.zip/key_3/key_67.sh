java -jar getLatinTag.jar in hi  "अलग" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मुश्किल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चिकित्सक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कृपया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "रक्षा" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "सटीक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रतीक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मरना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कम से कम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मुसीबत" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "सदी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "विचार करना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्रकार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कानून" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बिट" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "विधि" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अंग" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "भुगतान" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "उम्र" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अनुभाग" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "विकसित" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सागर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "गर्म" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मुक्त" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मिनट" 1000  keyword_hi.txt

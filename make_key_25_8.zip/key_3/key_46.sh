java -jar getLatinTag.jar in hi  "सड़क" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नक्शा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बारिश" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नियम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शासन" 1000  keyword_hi.txt

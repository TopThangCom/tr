java -jar getLatinTag.jar in hi  "कपड़े" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अजीब" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चला गया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "व्यापार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "राग" 1000  keyword_hi.txt

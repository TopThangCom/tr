java -jar getLatinTag.jar in hi  "बांह" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "विस्तृत" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "स्टील अथॉरिटी ऑफ इंडिया" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सामग्री" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अंश" 1000  keyword_hi.txt

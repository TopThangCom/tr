java -jar getLatinTag.jar in hi  "पैर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "व्यायाम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दीवार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पकड़" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "माउंट" 1000  keyword_hi.txt

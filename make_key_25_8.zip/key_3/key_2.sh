java -jar getLatinTag.jar in hi  "छोटे" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चढ़ाई" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "शीतल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "डिजाइन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "गरीब" 1000  keyword_hi.txt

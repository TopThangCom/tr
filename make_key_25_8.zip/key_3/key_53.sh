java -jar getLatinTag.jar in hi  "तट" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नकल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "वाक्यांश" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चुप" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लंबा" 1000  keyword_hi.txt

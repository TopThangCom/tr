java -jar getLatinTag.jar in hi  "आठ" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "गांव" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मिलो" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जड़" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "खरीद" 1000  keyword_hi.txt

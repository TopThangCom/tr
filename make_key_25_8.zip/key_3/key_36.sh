java -jar getLatinTag.jar in hi  "यात्रा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कार्यालय" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "प्राप्त करना" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पंक्ति" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मुंह" 1000  keyword_hi.txt

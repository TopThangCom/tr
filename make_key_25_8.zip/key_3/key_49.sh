java -jar getLatinTag.jar in hi  "शिकार" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "संभावित" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बिस्तर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "भाई" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अंडा" 1000  keyword_hi.txt

java -jar getLatinTag.jar in hi  "परिणाम" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जला" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पहाड़ी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सुरक्षित" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बिल्ली" 1000  keyword_hi.txt

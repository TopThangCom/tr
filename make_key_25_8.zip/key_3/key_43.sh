java -jar getLatinTag.jar in hi  "स्थिति जानें" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "अंगूठी" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "चरित्र" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कीट" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "पकड़ा" 1000  keyword_hi.txt

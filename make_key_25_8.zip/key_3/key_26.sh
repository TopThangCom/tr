java -jar getLatinTag.jar in hi  "शनि" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लिखित" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "जंगली" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "साधन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "रखा" 1000  keyword_hi.txt

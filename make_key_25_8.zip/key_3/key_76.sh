java -jar getLatinTag.jar in hi  "गर्मियों" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "सफर" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नींद" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "साबित" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "लोन" 1000  keyword_hi.txt

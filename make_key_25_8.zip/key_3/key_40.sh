java -jar getLatinTag.jar in hi  "बाल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "वर्णन" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कुक" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "मंजिल" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "भी" 1000  keyword_hi.txt

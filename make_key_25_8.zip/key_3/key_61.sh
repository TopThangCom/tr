java -jar getLatinTag.jar in hi  "भालू" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "खत्म" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "खुश" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "आशा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "फूल" 1000  keyword_hi.txt

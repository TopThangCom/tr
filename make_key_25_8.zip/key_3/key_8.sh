java -jar getLatinTag.jar in hi  "इकट्ठा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "बचा" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "नियंत्रण" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "दशमलव" 1000  keyword_hi.txt
java -jar getLatinTag.jar in hi  "कान" 1000  keyword_hi.txt

java -jar getLatinTag.jar bd bn  "অনেক" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "গড়" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "আগে" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "পদক্ষেপ" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "অধিকার" 1000  keyword_bn.txt

java -jar getLatinTag.jar bd bn  "কিন্তু" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "কি" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "কিছু" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "হয়" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "এটা" 1000  keyword_bn.txt

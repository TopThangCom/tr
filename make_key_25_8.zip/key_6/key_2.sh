java -jar getLatinTag.jar bd bn  "প্রস্তুত" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "উপরে" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "কখনও" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "লাল" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "তালিকা" 1000  keyword_bn.txt

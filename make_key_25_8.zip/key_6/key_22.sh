java -jar getLatinTag.jar bd bn  "দেশ" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "পাওয়া" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "উত্তর" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "স্কুল" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "হত্তয়া" 1000  keyword_bn.txt

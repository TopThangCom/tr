java -jar getLatinTag.jar bd bn  "পাওয়া" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "স্থান" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "তৈরি" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "বাস" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "যেখানে" 1000  keyword_bn.txt

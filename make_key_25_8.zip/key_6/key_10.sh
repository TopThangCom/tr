java -jar getLatinTag.jar bd bn  "নাম" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "খুব" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "মাধ্যমে" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "ঠিক" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "ফর্ম" 1000  keyword_bn.txt

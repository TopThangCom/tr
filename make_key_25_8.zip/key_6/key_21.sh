java -jar getLatinTag.jar bd bn  "তুলনায়" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "কল" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "প্রথম" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "যারা" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "হতে পারে" 1000  keyword_bn.txt

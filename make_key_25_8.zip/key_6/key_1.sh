java -jar getLatinTag.jar bd bn  "শরীর" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "কুকুর" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "পরিবার" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "সরাসরি" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "জাহির করা" 1000  keyword_bn.txt

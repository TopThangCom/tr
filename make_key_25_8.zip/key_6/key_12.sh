java -jar getLatinTag.jar bd bn  "চিন্তার" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "শহর" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "গাছ" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "ক্রুশ" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "খামার" 1000  keyword_bn.txt

java -jar getLatinTag.jar bd bn  "সব" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "সেখানে" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "যখন" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "আপ" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "ব্যবহার" 1000  keyword_bn.txt

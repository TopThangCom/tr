java -jar getLatinTag.jar bd bn  "পর্বত" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "বন্ধ" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "একবার" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "ঘাঁটি" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "শ্রবণ" 1000  keyword_bn.txt

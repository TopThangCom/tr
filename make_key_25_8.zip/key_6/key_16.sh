java -jar getLatinTag.jar bd bn  "বড়" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "বানান" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "যোগ করা" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "এমনকি" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "জমি" 1000  keyword_bn.txt

java -jar getLatinTag.jar bd bn  "দেখা" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "তাকে" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "দুই" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "আছে" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "চেহারা" 1000  keyword_bn.txt

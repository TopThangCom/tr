java -jar getLatinTag.jar bd bn  "যদিও" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "মনে" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "আলাপ" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "পাখি" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "শীঘ্রই" 1000  keyword_bn.txt

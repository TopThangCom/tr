java -jar getLatinTag.jar bd bn  "গ্রুপ" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "সবসময়" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "সঙ্গীত" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "যারা" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "উভয়" 1000  keyword_bn.txt

java -jar getLatinTag.jar bd bn  "না" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "সেট" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "তিন" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "চান" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "বায়ু" 1000  keyword_bn.txt

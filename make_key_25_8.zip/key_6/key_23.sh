java -jar getLatinTag.jar bd bn  "ঘোড়া" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "কাটা" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "নিশ্চিত" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "ঘড়ি" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "রঙ" 1000  keyword_bn.txt

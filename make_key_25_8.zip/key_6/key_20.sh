java -jar getLatinTag.jar bd bn  "কি" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "সংখ্যা" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "শব্দ" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "কোন" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "সবচেয়ে" 1000  keyword_bn.txt

java -jar getLatinTag.jar bd bn  "ভাল" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "আমাকে" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "দিতে" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "আমাদের" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "অধীন" 1000  keyword_bn.txt

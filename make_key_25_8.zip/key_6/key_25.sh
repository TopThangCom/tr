java -jar getLatinTag.jar bd bn  "এখানে" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "অবশ্যই" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "বড়" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "উচ্চ" 1000  keyword_bn.txt
java -jar getLatinTag.jar bd bn  "এমন" 1000  keyword_bn.txt

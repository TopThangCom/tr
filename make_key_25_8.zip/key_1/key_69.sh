java -jar getLatinTag.jar jp ja  "缶" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "アウト" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "その他" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "だった" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "これ" 1000  keyword_ja.txt

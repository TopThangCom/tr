java -jar getLatinTag.jar jp ja  "それら" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "書く" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "でしょう" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ような" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "そう" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "多くの" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "日" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "可能性" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "行く" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "来る" 1000  keyword_ja.txt

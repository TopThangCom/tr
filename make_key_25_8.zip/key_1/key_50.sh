java -jar getLatinTag.jar jp ja  "足" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "システム" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "忙しい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "テスト" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "記録" 1000  keyword_ja.txt

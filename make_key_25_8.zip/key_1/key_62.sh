java -jar getLatinTag.jar jp ja  "食品" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "太陽" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "つの" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "間に" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "状態" 1000  keyword_ja.txt

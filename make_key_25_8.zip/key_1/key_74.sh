java -jar getLatinTag.jar jp ja  "続く" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "行為" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "なぜ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "頼む" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "人々" 1000  keyword_ja.txt

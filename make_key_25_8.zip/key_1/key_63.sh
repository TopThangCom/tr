java -jar getLatinTag.jar jp ja  "雪" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "タイヤ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "持って来る" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "はい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "遠い" 1000  keyword_ja.txt

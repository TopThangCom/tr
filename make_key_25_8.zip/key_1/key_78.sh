java -jar getLatinTag.jar jp ja  "顔" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "木材" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "メイン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "オープン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "見える" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "あなた" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "または" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "持っていた" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "インクルード" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "の" 1000  keyword_ja.txt

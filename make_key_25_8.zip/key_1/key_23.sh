java -jar getLatinTag.jar jp ja  "馬" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "カット" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "確か" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "見る" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "カラー" 1000  keyword_ja.txt

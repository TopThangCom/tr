java -jar getLatinTag.jar jp ja  "やった" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "番号" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "聞こえる" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "いいえ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "最も" 1000  keyword_ja.txt

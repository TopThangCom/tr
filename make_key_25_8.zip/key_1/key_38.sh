java -jar getLatinTag.jar jp ja  "研究" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "まだ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "学ぶ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "植物" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "カバー" 1000  keyword_ja.txt

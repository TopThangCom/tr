java -jar getLatinTag.jar jp ja  "グループ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "常に" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "音楽" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "それらの" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "両方" 1000  keyword_ja.txt

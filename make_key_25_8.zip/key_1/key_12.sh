java -jar getLatinTag.jar jp ja  "考え" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "街" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ツリー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "クロス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "農場" 1000  keyword_ja.txt

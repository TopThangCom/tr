java -jar getLatinTag.jar jp ja  "彼ら" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ある" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "アット" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "一つ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "持っている" 1000  keyword_ja.txt

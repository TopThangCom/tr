java -jar getLatinTag.jar jp ja  "へ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "そして" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "は" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "で" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "我々" 1000  keyword_ja.txt

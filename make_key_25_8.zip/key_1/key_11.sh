java -jar getLatinTag.jar jp ja  "ずっと" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "意味する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "前に" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "移動" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "権利" 1000  keyword_ja.txt

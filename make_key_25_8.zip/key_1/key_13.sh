java -jar getLatinTag.jar jp ja  "良い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "私に" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "与える" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "私たちの" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "下" 1000  keyword_ja.txt

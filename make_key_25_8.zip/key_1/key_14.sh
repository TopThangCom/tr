java -jar getLatinTag.jar jp ja  "すべて" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "そこ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "時" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "アップ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "使用" 1000  keyword_ja.txt

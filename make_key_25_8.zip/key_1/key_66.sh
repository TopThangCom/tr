java -jar getLatinTag.jar jp ja  "男の子" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "古い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "あまりに" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "同じ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "彼女" 1000  keyword_ja.txt

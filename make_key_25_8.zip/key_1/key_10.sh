java -jar getLatinTag.jar jp ja  "名前" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "非常に" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "スルー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ただ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "フォーム" 1000  keyword_ja.txt

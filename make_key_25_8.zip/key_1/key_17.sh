java -jar getLatinTag.jar jp ja  "しかし" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "感じる" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "トーク" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "鳥" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "すぐに" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "黒" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "短い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "数字" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "クラス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "風" 1000  keyword_ja.txt

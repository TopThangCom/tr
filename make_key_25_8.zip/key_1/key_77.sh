java -jar getLatinTag.jar jp ja  "低い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ライン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "異なる" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ターン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "原因" 1000  keyword_ja.txt

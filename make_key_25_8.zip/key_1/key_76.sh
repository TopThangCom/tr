java -jar getLatinTag.jar jp ja  "ように" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "私は" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "彼の" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "その" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "彼" 1000  keyword_ja.txt

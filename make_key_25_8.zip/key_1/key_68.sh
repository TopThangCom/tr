java -jar getLatinTag.jar jp ja  "決定する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "表面" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "深い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ムーン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "島" 1000  keyword_ja.txt

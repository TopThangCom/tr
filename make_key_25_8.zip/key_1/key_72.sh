java -jar getLatinTag.jar jp ja  "一緒に" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "次" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "白" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "子どもたち" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "始まる" 1000  keyword_ja.txt

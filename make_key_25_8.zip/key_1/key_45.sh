java -jar getLatinTag.jar jp ja  "ヘッド" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "スタンド" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "独自の" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ページ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "べき" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "インチ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "掛ける" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "何も" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "もちろん" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "滞在" 1000  keyword_ja.txt

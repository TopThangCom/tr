java -jar getLatinTag.jar jp ja  "国" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "発見" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "答え" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "学校" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "成長する" 1000  keyword_ja.txt

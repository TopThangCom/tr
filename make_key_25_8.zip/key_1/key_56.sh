java -jar getLatinTag.jar jp ja  "この" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "から" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "バイ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ホット" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "言葉" 1000  keyword_ja.txt

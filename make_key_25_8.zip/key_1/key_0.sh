java -jar getLatinTag.jar jp ja  "見る" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "彼に" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "二つ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "があります" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "見える" 1000  keyword_ja.txt

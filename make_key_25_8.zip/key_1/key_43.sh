java -jar getLatinTag.jar jp ja  "ホイール" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "フル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "力" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ブルー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "オブジェクト" 1000  keyword_ja.txt

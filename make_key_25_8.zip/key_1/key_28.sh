java -jar getLatinTag.jar jp ja  "代わり" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ドライ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "不思議" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "笑い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "千の" 1000  keyword_ja.txt

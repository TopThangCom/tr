java -jar getLatinTag.jar jp ja  "あなたの" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "道" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "約" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "多くの" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "その後" 1000  keyword_ja.txt

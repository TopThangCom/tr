java -jar getLatinTag.jar jp ja  "川" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "カー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "フィート" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "介護" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "第2" 1000  keyword_ja.txt

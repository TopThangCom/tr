java -jar getLatinTag.jar jp ja  "変更" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "行ってきました" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "光" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "種類" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "オフ" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "やる" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "それらの" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "時間" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "もし" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "意志" 1000  keyword_ja.txt

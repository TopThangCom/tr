java -jar getLatinTag.jar jp ja  "ダウン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "サイド" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "き" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "今" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "見つける" 1000  keyword_ja.txt

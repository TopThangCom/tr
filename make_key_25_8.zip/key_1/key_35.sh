java -jar getLatinTag.jar jp ja  "半分" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "岩" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "オーダー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "火災" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "南" 1000  keyword_ja.txt

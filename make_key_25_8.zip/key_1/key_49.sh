java -jar getLatinTag.jar jp ja  "ボート" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "一般的な" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ゴールド" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "可能" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "飛行機" 1000  keyword_ja.txt

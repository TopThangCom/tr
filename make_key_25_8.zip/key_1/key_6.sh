java -jar getLatinTag.jar jp ja  "去る" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "歌" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "測定" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ドア" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "製品" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "必要" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "家" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "絵" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "試す" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "私たち" 1000  keyword_ja.txt

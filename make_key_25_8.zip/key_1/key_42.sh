java -jar getLatinTag.jar jp ja  "これらの" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "彼女の" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "長い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "作る" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "もの" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "近く" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ビルド" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "自己" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "地球" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "父" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "一致する" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ホット" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ミス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "た" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "熱" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "比べて" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "コール" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "最初の" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "誰" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "よい" 1000  keyword_ja.txt

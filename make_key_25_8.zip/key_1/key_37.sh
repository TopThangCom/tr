java -jar getLatinTag.jar jp ja  "再び" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "動物" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ポイント" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "母" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "世界" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "ブック" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "運ぶ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "かかった" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "科学" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "食べる" 1000  keyword_ja.txt

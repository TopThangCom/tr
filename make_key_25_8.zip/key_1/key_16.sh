java -jar getLatinTag.jar jp ja  "大きい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "スペル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "加える" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "さらに" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "土地" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "前" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "走った" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "チェック" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ゲーム" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "形状" 1000  keyword_ja.txt

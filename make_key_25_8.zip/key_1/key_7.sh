java -jar getLatinTag.jar jp ja  "質問" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "起こる" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "完全な" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "船" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "エリア" 1000  keyword_ja.txt

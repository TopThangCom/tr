java -jar getLatinTag.jar jp ja  "ここに" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "しなければならない" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "大きい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "高い" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "そのような" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "部屋" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "友人" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "始まった" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "アイデア" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "魚" 1000  keyword_ja.txt

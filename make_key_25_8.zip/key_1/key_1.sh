java -jar getLatinTag.jar jp ja  "ボディ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "犬" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "家族" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ダイレクト" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ポーズ" 1000  keyword_ja.txt

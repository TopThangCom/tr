java -jar getLatinTag.jar jp ja  "マーク" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "しばしば" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "手紙" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "まで、" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "マイル" 1000  keyword_ja.txt

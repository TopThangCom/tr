java -jar getLatinTag.jar jp ja  "十分な" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "平野" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "女の子" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "いつもの" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "若い" 1000  keyword_ja.txt

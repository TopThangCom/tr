java -jar getLatinTag.jar jp ja  "方法" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "前記" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "の" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "それぞれ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "言う" 1000  keyword_ja.txt

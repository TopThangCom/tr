java -jar getLatinTag.jar jp ja  "夜" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "リアル" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "生活" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "少数" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "北" 1000  keyword_ja.txt

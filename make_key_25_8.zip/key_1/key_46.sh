java -jar getLatinTag.jar jp ja  "人々" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "私の" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "オーバー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "知っている" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "水" 1000  keyword_ja.txt

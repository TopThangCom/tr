java -jar getLatinTag.jar jp ja  "ラン" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ない" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "一方、" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "プレス" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "クローズ" 1000  keyword_ja.txt

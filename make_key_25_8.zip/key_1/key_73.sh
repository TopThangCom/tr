java -jar getLatinTag.jar jp ja  "文" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "素晴らしい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "思う" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "言う" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "助け" 1000  keyword_ja.txt

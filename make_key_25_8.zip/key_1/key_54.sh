java -jar getLatinTag.jar jp ja  "男" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "年" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "来た" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ショー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "すべての" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "よく" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "また" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "遊ぶ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "小さい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "終わり" 1000  keyword_ja.txt

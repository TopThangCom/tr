java -jar getLatinTag.jar jp ja  "しかし" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "何" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "いくつかの" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "です" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "それ" 1000  keyword_ja.txt

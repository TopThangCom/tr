java -jar getLatinTag.jar jp ja  "問題" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "作品" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "言われ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "知っていた" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "合格" 1000  keyword_ja.txt

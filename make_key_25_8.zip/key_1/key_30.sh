java -jar getLatinTag.jar jp ja  "キープ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "目" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ネバー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "最後の" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "てみましょう" 1000  keyword_ja.txt

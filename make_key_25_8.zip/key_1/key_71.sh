java -jar getLatinTag.jar jp ja  "た" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ために" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "上の" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "アール" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "とともに" 1000  keyword_ja.txt

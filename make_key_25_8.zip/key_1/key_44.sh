java -jar getLatinTag.jar jp ja  "埋める" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "東" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ペイント" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "言語" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "の間で" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "ゲット" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "場所" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "製" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "暮らす" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "どこ" 1000  keyword_ja.txt

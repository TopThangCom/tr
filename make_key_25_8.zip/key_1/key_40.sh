java -jar getLatinTag.jar jp ja  "以来" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "トップ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "全体" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "王" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ストリート" 1000  keyword_ja.txt

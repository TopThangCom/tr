java -jar getLatinTag.jar jp ja  "後に" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "バック" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "少し" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "唯一の" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ラウンド" 1000  keyword_ja.txt

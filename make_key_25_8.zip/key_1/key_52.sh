java -jar getLatinTag.jar jp ja  "遠く" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "海" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "描く" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "左" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "遅く" 1000  keyword_ja.txt

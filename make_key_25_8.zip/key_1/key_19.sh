java -jar getLatinTag.jar jp ja  "し" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "セット" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "個" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "欲しい" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "空気" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "だ" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "歩く" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "例" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "和らげる" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "紙" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "山" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "停止" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "一度" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ベース" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "聞く" 1000  keyword_ja.txt

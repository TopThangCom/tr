java -jar getLatinTag.jar jp ja  "レディー" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "上記" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "今までに" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "赤" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "リスト" 1000  keyword_ja.txt

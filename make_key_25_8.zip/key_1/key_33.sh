java -jar getLatinTag.jar jp ja  "置く" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ホーム" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "読む" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "手" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "ポート" 1000  keyword_ja.txt

java -jar getLatinTag.jar jp ja  "ハード" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "スタート" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "可能性がある" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "物語" 1000  keyword_ja.txt
java -jar getLatinTag.jar jp ja  "のこぎり" 1000  keyword_ja.txt
